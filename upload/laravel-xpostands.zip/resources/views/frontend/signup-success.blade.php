<!doctype html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    @include('frontend.includes.commoncss')
    <link rel="stylesheet" href="{{asset('frontend/css/contractor-signup.min.css')}}">
    <title>Contractor Signup</title>
</head>

<body class="d-flex flex-column h-100">
<router-view></router-view>
    <!-- BEGIN: HEADER PANEL -->
    @include('frontend.includes.secondryheader')
    <!-- END: HEADER PANEL -->

    <main class="add-secondary-header" id="stand-request-panel">
      
        <!-- ==================================== -->
        <!-- Main Area -->
        <!-- ==================================== -->
        <section class="pt-3 pb-5">
            <div class="container-fluid container-md">
                <div class="row g-3">
                   
                    <!-- ****************************************** -->
                    <!-- Thanks Panel -->
                    <!-- ****************************************** -->
                    <div class="col-lg-10 mx-auto">
                        <div class="display-5 text-center fw-bold">Thank you for reaching us!</div>
                        <div class="display-5 text-center">we have received your request and our representative will get in touch with you soon.</div>
                    </div>
                </div>
            </div>
        </section>
    </main>


    <!-- BEGIN: FOOTER PANEL -->
    @include('frontend.includes.footer')
    <!-- END: FOOTER PANEL -->
    
    @include('frontend.includes.commonJS')
    

    <script>
        createApp({
    data() {
        return {
            formData:{
            },
            enquiryData:{
            }
        }
    },
    mounted(){
        console.log("From App Two")
    },
    }).mount('#stand-request-panel')
    </script>
</body>

</html>