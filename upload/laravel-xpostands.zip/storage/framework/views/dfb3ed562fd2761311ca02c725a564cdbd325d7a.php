<li class="nav-item me-lg-4">
    <a class="nav-link text-center text-uppercase p-xl-0 fs-5 d-flex align-items-center" aria-current="page" href="/">
        <span>
            <i class="bi bi-house-door-fill"></i>
        </span>
    </a>
</li>
<li class="nav-item me-lg-4">
    <a class="nav-link text-center text-uppercase p-xl-0 py-0" href="about.php">About us</a>
</li>
<li class="nav-item me-lg-4">
    <a class="nav-link text-center text-uppercase p-xl-0 py-0" href="our-presence.php">Our Presence</a>
</li>
<li class="nav-item me-lg-4">
    <a class="nav-link text-center text-uppercase p-xl-0 py-0" href="how-it-works.php">How it works?</a>
</li>
<li class="nav-item me-lg-4">
    <a class="nav-link text-center text-uppercase p-xl-0 py-0" href="#">Blog</a>
</li>
<li class="nav-item me-lg-4">
    <a class="nav-link text-center text-uppercase p-xl-0 py-0" href="contact.php">Contact us</a>
</li><?php /**PATH D:\projects\project\resources\views/frontend/includes/primary-menu.blade.php ENDPATH**/ ?>