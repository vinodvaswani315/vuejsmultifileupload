<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/vue-router@4.1.6/dist/vue-router.global.js"></script>
<script>
    function myFunction(x) {
        x.classList.toggle("change");
    }
</script>
<script>
  var APP_URL = <?php echo json_encode(url('/')); ?>

  
  const { createApp } = Vue
    
    axios.defaults.headers.common = {
    'X-CSRF-TOKEN' : document.querySelector('meta[name="csrf-token"]').getAttribute('content')
    };
    
    createApp({
    data() {
        return {
            formData:{
            },
            enquiryData:{

            }
        }
    },
    mounted(){
        console.log("From App One")
    },
    methods:{
        onLogin(){
            axios.post("login", { email:this.email,password:this.password }).then(function (response) {
                
                if(response.data.status=='success')
                {
                    window.location.href = APP_URL+response.data.goto
                }
                
            }).catch((errors)=>{
                
                this.loading = false;
                
                $(".is-invalid").removeClass('is-invalid')
                Object.keys(errors.response.data.error).forEach((key,index)=>
                {
                    var el = this.$refs[key]
                    el.classList.remove("is-invalid")
                    el.nextElementSibling.innerHTML = errors.response.data.error[key][0]
                    el.classList.add("is-invalid")

                    if(index==0)
                    {
                        el.scrollIntoView({
                            behavior: "smooth",
                            block: "end",
                            inline: "nearest",
                        });
                    }
                })
                
            });
        }
    }
    }).mount('#loginModal')
</script><?php /**PATH E:\laravel-xpostands\resources\views/frontend/includes/commonJS.blade.php ENDPATH**/ ?>