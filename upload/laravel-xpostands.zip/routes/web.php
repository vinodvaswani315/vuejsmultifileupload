<?php

use App\Http\Controllers\AdminDashboardController;
use App\Http\Controllers\ContractorSignup;
use App\Http\Controllers\EnquiryController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\FaqController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/signup-success', function () {
    return view('frontend.signup-success');
})->name('signupSuccess');

Route::get('/send-enquiry', [EnquiryController::class,'edit']);
Route::get('/contractor-signup', [ContractorSignup::class,'create']);
Route::post('/contractor-signup', [ContractorSignup::class,'store']);

Route::post('/update-enquiry', [EnquiryController::class,'update']);
Route::post('/save-enquiry', [EnquiryController::class,'store']);

Auth::routes();

Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::group(['prefix' => 'contractor', 'middleware' => ['auth', 'contractor']], function () {
    
    Route::get('/dashboard', function () {
        return view('contractor/index');
    });


});


Route::get('superadmin/login', function () {
    return view('admin/login');
});



Route::get('/superadmin', function () {
    if(is_null(Auth::user()))
    {
        return redirect('/superadmin/login');
    }
    else
    {
        return redirect('/superadmin/dashboard');
    }
});

Route::group(['prefix' => 'superadmin', 'middleware' => ['auth', 'superadmin']], function () {
    

    Route::get('/dashboard',[App\Http\Controllers\AdminDashboardController::class,'index'])->name('admindashboard');

    Route::get('/enquiries', [App\Http\Controllers\EnquiryController::class, 'index'])->name('enquiries');
    Route::get('/enquiry-details/{enquiry_id}', [App\Http\Controllers\EnquiryController::class, 'enquiry_details'])->name('enquiry_details');
    
    // Contractors Routes
    Route::get('/contractors', [App\Http\Controllers\UserController::class, 'index'])->name('contractors');
    Route::get('/users', [App\Http\Controllers\UserController::class, 'users_index'])->name('users');



    Route::get('/faqs', [App\Http\Controllers\FaqController::class, 'index'])->name('faqs');
    Route::get('/faqs/{id}/edit', [App\Http\Controllers\FaqController::class, 'edit'])->name('faqsEdit');
    Route::get('/faqs/new', [App\Http\Controllers\FaqController::class, 'show'])->name('faqsAdd');
    Route::put('/faqs/new', [App\Http\Controllers\FaqController::class, 'store'])->name('faqsStore');
    Route::put('/faqs/{id}', [App\Http\Controllers\FaqController::class, 'update'])->name('faqsUpdate');
    Route::delete('/faqs/destroy/{id}', [App\Http\Controllers\FaqController::class, 'destroy'])->name('faqsDestroy');
    
});