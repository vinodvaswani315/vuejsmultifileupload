@extends('layouts.master')
@section('contents')
<section role="main" class="content-body">
    <header class="page-header d-flex">
        <div>
            <a class="page-title-icon" href="{{url('super-admin/dashboard')}}"><i class="fas fa-home"></i></a>
            <h2>University</h2>
        </div>
        <div style="margin-left: 59%; margin-top:10px;" id="show_all_university">
            

        </div>
    </header>
    <section class="panel">
        <div class="tabs-custom">
            <ul class="nav nav-tabs">
                <li class="list_data_tab">
                <a href="{{ url('super-admin/universities') }}"><i class="fas fa-list-ul"></i> University List</a>
                </li>
                <li class="create_data_tab active">
                <a href="#create" data-toggle="tab"><i class="far fa-edit"></i> Create University</a>
                </li>
                {{-- <li class="edit_data_tab" >
                <a href="#edit-form" data-toggle="tab" id="edit-form-achor"><i class="far fa-edit"></i> Edit Record</a>
                </li> --}}
            </ul>
            <div class="tab-content">

                <div class="tab-pane active" id="create">
                    <form class="form-horizontal form-bordered validate" action="{{ url('super-admin/universities') }}" method="POST" accept-charset="utf-8" enctype="multipart/form-data">
                        @csrf
                     
                        
                        <div class="form-group mt-md">
                            
                            <label class="col-md-3 control-label">University Name <span class="required">*</span></label>
                            
                            <div class="col-md-6">

                                <input type="text" class="form-control" name="university_name" value="{{ old('university_name') }}" id="university_name" />
                                @if ($errors->has('university_name'))
                                    <span class="text-danger">{{ $errors->first('university_name') }}</span>
                                @endif
                               
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">College Name <span class="required">*</span></label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="college_name" value="{{ old('college_name') }}" id="college_name" />
                                @if ($errors->has('college_name'))
                                    <span class="text-danger">{{ $errors->first('college_name') }}</span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">Email <span class="required">*</span></label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="email" value="{{ old('email') }}" id="email" />
                                @if ($errors->has('email'))
                                    <span class="text-danger">{{ $errors->first('email') }}</span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">Mobile No <span class="required">*</span></label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="mobile" value="{{ old('mobile') }}" id="mobile">
                                @if ($errors->has('mobile'))
                                    <span class="text-danger">{{ $errors->first('mobile') }}</span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">City</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="city" value="{{ old('city') }}" id="city">
                                <div class="city_error error_div"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">State</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="state" value="{{ old('state') }}" id="state">
                                <div class="state_error error_div"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label  class="col-md-3 control-label">Address</label>
                            <div class="col-md-6 mb-md">
                                <textarea type="text" rows="3" class="form-control" name="address"  id="address" >{{ old('address') }}</textarea>
                                <div class="address_error error_div"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">Link</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="link" value="{{ old('link') }}" id="link">
                                <div class="link_error error_div"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">Logo<span class="required">*</span></label>
                            <div class="col-md-6">
                                <input type="file" class="form-control" name="logo" id="logo">
                                @if ($errors->has('logo'))
                                    <span class="text-danger">{{ $errors->first('logo') }}</span>
                                @endif
                            </div>
                        </div>
                        <footer class="panel-footer mt-lg">
                            <div class="row">
                                <div class="col-md-2 col-md-offset-3">
                                    <button type="submit" class="btn btn-default btn-block" id="add_university_submit">
                                        <i class="fas fa-plus-circle"></i> Save								
                                    </button>
                                </div>
                            </div>
                        </footer>
                    </form>
                </div>
                
            </div>
        </div>
    </section>
 </section>
@endsection
@section('js')
<script>
   
</script>


@endsection