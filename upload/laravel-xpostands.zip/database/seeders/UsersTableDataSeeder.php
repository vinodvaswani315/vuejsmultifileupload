<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\UserRole;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UsersTableDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = new User();
        $user->name = "superadmin";
        $user->email = 'admin@mail.com';
        $user->password = bcrypt('123456');
        $user->save();

        $user_id = $user->id;

        UserRole::create([
            'user_id'=> $user_id,
            'role_id'=> 1
        ]);

    }
}
