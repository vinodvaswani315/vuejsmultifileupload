<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\University;
use Validator;
use Session;

class UniversityController extends Controller
{
    
    public function index()
    {
         
        $university['university'] = University::all();
        return view('Admin.university.university',$university);
    }
    
    
    public function create()
    {
        
        return view('Admin.university.add_university');
    }

    public function store(Request $request)
    {
        $request->validate([
            'university_name'=>'required',
            'college_name'=>'required',
            'email'       =>'required',
            'mobile' => 'required',
            'logo' => 'required',
        ]);
        
        $university = new University();

        $university -> university_name = $request -> university_name;

        $university -> college_name = $request -> college_name;

        $university -> email = $request -> email;

        $university -> mobile = $request -> mobile;

        $university -> city = $request -> city;

        $university -> state = $request -> state;

        $university -> link = $request -> link;

        $university -> address = $request -> address;
        
        if($request->hasFile('logo'))
        {
            $file = $request->file('logo');
            $extension = $file->getClientOriginalExtension();
            $filename =time() .'.' .$extension;
            $file->storeAS('/public/uploade',$filename);
            $university->logo =$filename;
            
        //    php artisan storage:link
        }

        $university ->save();

        $request->session()->flash('success','University has been Added');
        return redirect('super-admin/universities');

        
    }

    public function show($id)
    {
        //
    }

   
    public function edit($id)
    {
        // dd($id);
       $university['data'] = University::find($id);
       return view('Admin.university.university_edit',$university);
   
    }

   
    public function update(Request $request, $id)
    {
        $request->validate([
            'university_name'=>'required',
            'college_name'=>'required',
            'email'       =>'required',
            'mobile' => 'required',
        ]);
        $university = University::find($request -> id);

        $university -> university_name = $request -> university_name;

        $university -> college_name = $request -> college_name;

        $university -> email = $request -> email;

        $university -> mobile = $request -> mobile;

        $university -> city = $request -> city;

        $university -> state = $request -> state;
        
        $university -> link = $request -> link;

        $university -> address = $request -> address;

        if($request->hasFile('logo'))
        {
            $file = $request->file('logo');
            $extension = $file->getClientOriginalExtension();
            $filename =time() .'.' .$extension;
            $file->storeAS('/public/uploade',$filename);
            $university->logo =$filename;
        }


        $university ->update();

        $request->session()->flash('success','University has been Updated');
        return redirect('super-admin/universities');

        
    
    }


    public function destroy(Request $request,$id)
    {
        $model = University::find($id);        
        if($model->delete()){
            return response()->json
            $request->session()->flash("success","University has been Deleted");
            return redirect('super-admin/universities');
            
        }else{
            $request->session()->flash("error","Failed");
            return back();
        }
    }
    public function globalUniversity(Request $request){
        // $request->id;
        // dd($request->all());

        Session::put("global_univesity",$request->id);
        return true;
    }
    public function get_university(Request $request){
        
        return getCourseByUniversityId($request->id);

    }
    public function get_sem(Request $request){
        
        return getSemByCourseId($request->id);

    }
    public function getAllData(Request $request){
        $model['getBranch'] = getBranch($request->u_id);
        $model['getUniversity'] =getUniversity(); 
        $model['getSemYear'] = getSemYear($request->u_id);
        $model['getCourse'] = getCourse($request->u_id);
        return $model; 
    }
}
