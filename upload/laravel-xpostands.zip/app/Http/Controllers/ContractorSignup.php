<?php
namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserRole;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class ContractorSignup extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('frontend.contractor-signup');
    }

    public function store(Request $request)
    {

        $current_step = $request->step;

        switch ($current_step) {
            case 1:
                $dynamic_validation = [
                    'first_name' => 'required',
                    'last_name' => 'required',
                    'password' => [
                        'required',
                        'min:6'
                    ],
                    'email' => 'required|email|unique:users'
                ];
                break;
                
            case 2:
                $dynamic_validation = [
                    'company_name' => 'required'
                ];
                break;
            
            default:
                $dynamic_validation = [];
                break;
        }

        $validator = Validator::make($request->all(), $dynamic_validation);

        if($request->onlyValidate)
        {
            if(!$validator->passes())
            {
                return response()->json(['goto_step'=> $current_step ,'error'=>$validator->errors()->toArray()],400);
            }
            else
            {
                return response()->json(['goto_step'=> $current_step+1,'error'=>$validator->errors()->toArray()],400);
            }
        }
        else if($request->validateAndSunmit)
        {
            if($validator->passes())
            {

                $user = User::create([
                    'name' => $request->first_name,
                    'last_name' => $request->last_name,
                    'email' => $request->email,
                    'password' => Hash::make($request->password),
                    'contact_number' => $request->contact_number,
                    'company_name' => $request->company_name,
                    'website' => $request->website,
                    'address' => $request->address,
                ]);

                $user_id = $user->id;

                $userrole = new UserRole();
                $userrole->user_id = $user->id;
                $userrole->role_id = 2; // Role ID of contractor
                $userrole->created_at = date('Y-m-d H:i:s');
                $userrole->updated_at = date('Y-m-d H:i:s');
                $userrole->save();

                // Save country id in junction table
                if(isset($request->countries) && count($request->countries))
                {
                    foreach($request->countries as $country_id)
                    {
                        DB::insert('insert into contractor_countries_junction( user_id,country_id) values (?,?)', [$user_id,$country_id]);
                    }
                }
                

                $mail_data = array(
                    'name'=> "vinod"
                );

                //Start Send Tour Booking Notification of the Customer
                // Mail::send('mail_notification.bookigTourConfirmation', $mail_data, function($message) use ($user) {
                //     $message->to($user->email)->subject('Confirmation Tour Booking');
                //     $message->from('chetu.amitkumar@gmail.com','ByoJeep');
                // });
                //End Send Tour Booking Notification of the Customer

                return response()->json(['status'=>'success','goto'=> 'signup-success'],200);
            }
        }
        else
        {
            return response()->json(['goto_step'=> $current_step,'error'=>$validator->errors()->toArray()],400);
        }
    }
}
