<!-- Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0">
                <!-- <h5 class="modal-title" id="loginModalLabel">Modal title</h5> -->
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" @submit.prevent="onLogin" method="post">
            <div class="modal-body px-lg-4">
                <div class="text-danger fs-4">Contractor Login</div>
                <div class="lead mb-4">Please enter your login credentials to access your account</div>

                <div class="form-floating mb-3">
                    <input type="email" v-model="email" ref="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                    <div id="validationServerUsernameFeedback" class="invalid-feedback">
                            Please enter email.
                    </div>
                    <label for="floatingInput">Email address</label>
                
            </div>
            <div class="form-floating mb-3">
                <input type="password" v-model="password" ref="password" class="form-control" id="floatingPassword" placeholder="Password">
                <div id="validationServerUsernameFeedback" class="invalid-feedback">
                    Please enter password.
                </div>
                <label for="floatingPassword">Password</label>
            </div>

            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Remember Me!</label>
            </div>

            <div class="d-flex w-100  justify-content-between">
                <button type="submit" class="btn btn-primary text-white px-4">Login</button>
                <a href="" class="text-decoration-none text-dark lead">Forgot Your Password?</a>
            </div>
        </div>
        <div class="modal-footer bg-light border-0 d-flex justify-content-between">
            <div class="text-decoration-none text-dark lead">Don’t have an account yet?</div>
            <button type="button" class="btn btn-outline-primary px-1 px-sm-3 hoverable">SignUp!</button>
        </div>
        </form>
    </div>
</div>
</div><?php /**PATH E:\xpostand\resources\views/frontend/includes/login-modal.blade.php ENDPATH**/ ?>