<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Middleware\Authenticate;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    public function login(Request $request)
    {
      // $validator = $request->validate([
      //     'email' => 'required',
      //     'password' => 'required',
      // ]);
      
      // dd($request->all());

      $validator = Validator::make($request->all(), [
        'email' => 'required',
        'password' => 'required'
       ]);

      $credentials = $request->only('email', 'password');

      $check_login = User::where(['email'=>$request->email])->first();
      

      if($check_login != null)
      {
        if(Hash::check($request->password, $check_login->password))
        {
            if (Auth::attempt($credentials))
            {
              return response()->json(['status'=>'success','goto'=> $this->redirectPath() ],200);
            }
        }
        else 
        {
          $validator->getMessageBag()->add('credentials', 'Wrong Email or Password entererd');
          return response()->json(['error'=>$validator->errors()->toArray()],400);
        }
      }
      else
      {
        $validator->getMessageBag()->add('email', 'No account found with this email');
        return response()->json(['error'=>$validator->errors()->toArray()],400);
      }
    }
    

    /**
     * Where to redirect users after login.
      *
     * @var string
     */
    // protected $redirectTo = RouteServiceProvider::HOME;
    public function redirectPath() {
        // dd(GetUserRole(auth()->user()->id));
        $role = GetUserRole(auth()->user()->id); 
       
        switch ($role) {

            case 'Contractor':
              return '/contractor/dashboard';
            break;
            case 'Superadmin':
              return '/superadmin/dashboard';
            break;
            case 'student':
              return '/student/dashboard';
            break; 
            case 'teacher':
              return '/teacher/dashboard';
            break; 
            case 'counsellor':
              return '/counsellor/dashboard';
            break; 
      
          default:
            return '/'; 
          break;
        }  
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
}
