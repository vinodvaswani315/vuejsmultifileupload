<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>All Enquiries</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <?php echo $__env->make('admin.includes.common-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.4.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- ======= Header Ends ======= -->
  
  <!-- ======= Sidebar ======= -->
  <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Enquiries</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
          <li class="breadcrumb-item active">Enquiries</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body pt-3">
                            <!-- <h5 class="card-title">Default Table</h5> -->

                            <!-- Default Table -->
                            <div class="table-responsive">
                                <table class="table small">
                                    <thead>
                                        <tr>
                                            <th scope="col"></th>
                                            <th scope="col">Lead No.</th>
                                            <th scope="col">Created</th>
                                            <th scope="col">Show Dates</th>
                                            <th scope="col">Company</th>
                                            <th scope="col">Show</th>
                                            <th scope="col">Area</th>
                                            <th scope="col">Location</th>
                                            <th scope="col">Status</th>
                                            <th scope="col"></th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr @click="openLead(<?php echo e($loop->index); ?>)" class="table-light">
                                            <th scope="row" class="bg-danger">
                                            </th>
                                            <th scope="row">#<?php echo e($item->id); ?></th>
                                            <td><?php echo e($item->created_at); ?></td>
                                            <td>05-08, Jan 2023</td>
                                            <td><?php echo e($item->company); ?></td>
                                            <td><?php echo e($item->event_name); ?> </td>
                                            <td>Barlin, 20200 </td>
                                            <td><?php echo e($item->event_country); ?></td>
                                            <td>
                                                <div class="d-flex gap-1">
                                                    <i class="bi bi-circle-fill"></i>
                                                    <i class="bi bi-circle-fill"></i>
                                                    <i class="bi bi-circle-fill"></i>
                                                    <i class="bi bi-circle"></i>
                                                    <i class="bi bi-circle"></i>
                                                </div>
                                            </td>
                                            <td><i class="bi bi-chevron-down"></i></td>
                                        </tr>

                                        <tr class="d-none" ref="row<?php echo e($loop->index); ?>">
                                            <td colspan="10">
                                                <div class="d-flex gap-3 align-items-center w-100">
                                                    <b>Performance:</b>
                                                    <button type="button"
                                                        class="btn btn-sm btn-primary gap-1 py-1 d-flex align-items-center">
                                                        Sent <span class="badge bg-white text-primary">20</span>
                                                    </button>

                                                    <button type="button"
                                                        class="btn btn-sm btn-secondary gap-1 py-1 d-flex align-items-center">
                                                        Sent <span class="badge bg-white text-secondary">20</span>
                                                    </button>

                                                    <button type="button"
                                                        class="btn btn-sm btn-success gap-1 py-1 d-flex align-items-center">
                                                        Sent <span class="badge bg-white text-success">20</span>
                                                    </button>

                                                    <button type="button"
                                                        class="btn btn-sm btn-danger gap-1 py-1 d-flex align-items-center">
                                                        Sent <span class="badge bg-white text-danger">20</span>
                                                    </button>

                                                    <button type="button"
                                                        class="btn btn-sm btn-warning gap-1 py-1 d-flex align-items-center">
                                                        Sent <span class="badge bg-white text-warning">20</span>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr class="d-none" ref="row<?php echo e($loop->index); ?>">
                                            <td colspan="4">
                                                <ul class="list-group list-group-flush">
                                                    <li class="list-group-item px-0">
                                                        <b>Berief</b>
                                                    </li>
                                                    <li class="list-group-item px-0">
                                                        <b>Name: </b> <?php echo e($item->contact_person_name); ?>

                                                    </li>
                                                    <li class="list-group-item px-0">
                                                        <b>Phone: </b> <?php echo e($item->contact_number); ?>

                                                    </li>
                                                    <li class="list-group-item px-0"><b>Email: </b> <?php echo e($item->email); ?></li>
                                                    <li class="list-group-item px-0"><b>Country: </b> <?php echo e($item->event_country); ?></li>
                                                </ul>
                                            </td>
                                            <td>
                                                <ul class="list-group list-group-flush">
                                                    <li class="list-group-item px-0">
                                                        <b>Builder 1</b>
                                                    </li>
                                                    <li class="list-group-item px-0">11 oct 2022, 11:11AM</li>
                                                    <li class="list-group-item px-0">NEO System</li>
                                                    <li class="list-group-item px-0">+14565 5561</li>
                                                    <li class="list-group-item px-0">adb@gmail.com</li>
                                                    <li class="list-group-item px-0">India</li>
                                                </ul>
                                            </td>
                                            <td>
                                                <ul class="list-group list-group-flush">
                                                    <li class="list-group-item px-0">
                                                        <b>Builder 2</b>
                                                    </li>
                                                    <li class="list-group-item px-0">11 oct 2022, 11:11AM</li>
                                                    <li class="list-group-item px-0">NEO System</li>
                                                    <li class="list-group-item px-0">+14565 5561</li>
                                                    <li class="list-group-item px-0">adb@gmail.com</li>
                                                    <li class="list-group-item px-0">India</li>
                                                </ul>
                                            </td>
                                            <td>
                                                <ul class="list-group list-group-flush">
                                                    <li class="list-group-item px-0">
                                                        <b>Builder 3</b>
                                                    </li>
                                                    <li class="list-group-item px-0">11 oct 2022, 11:11AM</li>
                                                    <li class="list-group-item px-0">NEO System</li>
                                                    <li class="list-group-item px-0">+14565 5561</li>
                                                    <li class="list-group-item px-0">adb@gmail.com</li>
                                                    <li class="list-group-item px-0">India</li>
                                                </ul>
                                            </td>
                                            <td>
                                                <ul class="list-group list-group-flush">
                                                    <li class="list-group-item px-0">
                                                        <b>Builder 4</b>
                                                    </li>
                                                    <li class="list-group-item px-0">11 oct 2022, 11:11AM</li>
                                                    <li class="list-group-item px-0">NEO System</li>
                                                    <li class="list-group-item px-0">+14565 5561</li>
                                                    <li class="list-group-item px-0">adb@gmail.com</li>
                                                    <li class="list-group-item px-0">India</li>
                                                </ul>
                                            </td>
                                            <td>
                                                <ul class="list-group list-group-flush">
                                                    <li class="list-group-item px-0">
                                                        <b>Builder 5</b>
                                                    </li>
                                                    <li class="list-group-item px-0">11 oct 2022, 11:11AM</li>
                                                    <li class="list-group-item px-0">NEO System</li>
                                                    <li class="list-group-item px-0">+14565 5561</li>
                                                    <li class="list-group-item px-0">adb@gmail.com</li>
                                                    <li class="list-group-item px-0">India</li>
                                                </ul>
                                            </td>
                                            <td style="width: 5%">
                                                <a href="enquiry-details/<?php echo e($item->id); ?>" type="button" class="btn btn-link text-decoration-none"><i
                                                        class="bi bi-send-fill"></i></a>
                                                <button type="button" class="btn btn-link text-decoration-none"><i
                                                        class="bi bi-arrow-repeat"></i></button>
                                                <button type="button" class="btn btn-link text-decoration-none"><i
                                                        class="bi bi-pencil-square"></i></button>
                                                <button type="button" class="btn btn-link text-decoration-none"><i
                                                        class="bi bi-archive-fill"></i></button>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <!-- <tr class="table-light">
                                            <th scope="row" class="bg-success">
                                            </th>
                                            <th scope="row">#451</th>
                                            <td>11 oct 2022, 11:11AM</td>
                                            <td>05-08, Jan 2023</td>
                                            <td>Ellips</td>
                                            <td>Logistica </td>
                                            <td>Barlin, 20200</td>
                                            <td>USA</td>
                                            <td>
                                                <div class="d-flex gap-1">
                                                    <i class="bi bi-circle-fill"></i>
                                                    <i class="bi bi-circle-fill"></i>
                                                    <i class="bi bi-circle-fill"></i>
                                                    <i class="bi bi-circle"></i>
                                                    <i class="bi bi-circle"></i>
                                                </div>
                                            </td>
                                            <td><i class="bi bi-chevron-down"></i></td>
                                        </tr>

                                        <tr class="table-light">
                                            <th scope="row" class="bg-warning">
                                            </th>
                                            <th scope="row">#450</th>
                                            <td>11 oct 2022, 11:11AM</td>
                                            <td>05-08, Jan 2023</td>
                                            <td>Ellips</td>
                                            <td>Logistica </td>
                                            <td>Barlin, 20200</td>
                                            <td>USA</td>
                                            <td>
                                                <div class="d-flex gap-1">
                                                    <i class="bi bi-circle-fill"></i>
                                                    <i class="bi bi-circle-fill"></i>
                                                    <i class="bi bi-circle-fill"></i>
                                                    <i class="bi bi-circle"></i>
                                                    <i class="bi bi-circle"></i>
                                                </div>
                                            </td>
                                            <td><i class="bi bi-chevron-down"></i></td>
                                        </tr> -->
                                    </tbody>
                                </table>

                                <?php echo e($enquiries->links()); ?>

                            </div>
                            <!-- End Default Table Example -->
                        </div>
                    </div>
                </div>
            </div>
        </section>

    

  </main><!-- End #main -->

 <!-- ======= Footer ======= -->
 <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <?php echo $__env->make('admin.includes.common-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
  <script>
  const { createApp } = Vue

  createApp({
      data() {
      return {
          message: 'Hello Vue!'
      }
      },
      methods:{
          openLead(i)
          {
              if(this.$refs['row'+i].classList.contains('d-none'))
              {
                  this.$refs['row'+i].classList.remove('d-none')
              }else
              {
                  this.$refs['row'+i].classList.add('d-none')
              }
          }
      }
  }).mount('#main')
  </script>
</body>

</html><?php /**PATH E:\laravel-xpostands\resources\views/admin/enquiries.blade.php ENDPATH**/ ?>