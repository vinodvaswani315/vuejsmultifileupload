<footer id="footer" class="footer">
</footer>
  <?php /**PATH D:\projects\project\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>