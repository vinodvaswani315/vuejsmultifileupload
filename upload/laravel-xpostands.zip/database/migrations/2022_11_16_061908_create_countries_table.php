<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCountriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('countries', function (Blueprint $table) {
            $table->id('country_id', true);
            $table->char('code', 2)->comment('Two-letter country code (ISO 3166-1 alpha-2)');
            $table->string('name', 64)->comment('English country name');
            $table->string('full_name', 128)->comment('Full English country name');
            $table->char('iso3', 3)->comment('Three-letter country code (ISO 3166-1 alpha-3)');
            $table->unsignedSmallInteger('number')->comment('Three-digit country number (ISO 3166-1 numeric)');
            $table->unsignedBigInteger('continent_id');
            $table->foreign('continent_id')->references('id')->on('continents')->onDelete('cascade');
            $table->integer('display_order')->default(900);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('countries');
    }
}
