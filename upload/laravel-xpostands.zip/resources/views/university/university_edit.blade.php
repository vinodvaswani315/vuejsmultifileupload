@extends('layouts.master')
@section('contents')
<section role="main" class="content-body">
    <header class="page-header">
        <a class="page-title-icon" href="{{url('super-admin/dashboard')}}"><i class="fas fa-home"></i></a>
        <h2>University</h2>
    </header>
    <section class="panel">
        <div class="tabs-custom">
            <ul class="nav nav-tabs">
                <li>
                <a href="{{url('super-admin/universities')}}"><i class="fas fa-list-ul"></i> University List</a>
                </li>
                
                <li class="active" >
                <a href="#edit-form" data-toggle="tab" id="edit-form-achor"><i class="far fa-edit"></i> Edit Record</a>
                </li>
            </ul>
            <div class="tab-content">

               
                <div class="tab-pane active" id="edit-form">
                    <form action="{{ route('universities.update',$data->id) }}" class="form-horizontal form-bordered validate" method="POST" enctype="multipart/form-data" accept-charset="utf-8">
                        @method('PUT')
                        @csrf
                        
                        <div class="form-group mt-md">
                            
                            <label class="col-md-3 control-label">University Name <span class="required">*</span></label>
                            
                            <div class="col-md-6">

                                <input type="text" class="form-control" name="university_name" id="edit_university_name" value="{{$data->university_name}}" />
                                @if ($errors->has('university_name'))
                                    <span class="text-danger">{{ $errors->first('university_name') }}</span>
                                @endif
                                
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">College Name <span class="required">*</span></label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="college_name" id="edit_college_name" value="{{$data->college_name}}" />
                                @if ($errors->has('college_name'))
                                    <span class="text-danger">{{ $errors->first('college_name') }}</span>
                                @endif
                            </div>
                        </div>
                        <input type="hidden" name="id" id="edit_university_id" value="{{$data->id}}">
                        <div class="form-group">
                            <label class="col-md-3 control-label">Email <span class="required">*</span></label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="email" id="edit_email" value="{{$data->email}}" />
                                @if ($errors->has('email'))
                                    <span class="text-danger">{{ $errors->first('email') }}</span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">Mobile No <span class="required">*</span></label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="mobile" id="edit_mobile" value="{{$data->mobile}}">
                                @if ($errors->has('mobile'))
                                    <span class="text-danger">{{ $errors->first('mobile') }}</span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">City</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="city" id="edit_city" value="{{$data->city}}">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">State</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="state" id="edit_state" value="{{$data->state}}">
                            </div>
                        </div>
                        <div class="form-group">
                            <label  class="col-md-3 control-label">Address</label>
                            <div class="col-md-6 mb-md">
                                <textarea type="text" rows="3" class="form-control" name="address" id="edit_address" >{{$data->address}}</textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">Link</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="link" id="edit_link" value="{{$data->link}}">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">Logo</label>
                            <div class="col-md-6">
                                <input type="file" class="form-control" name="logo" id="edit_logo" value="{{$data->logo}}">
                                <img class="" src="{{asset('storage/uploade/')}}/{{$data->logo}}" width="100" height="40">
                                @if ($errors->has('logo'))
                                    <span class="text-danger">{{ $errors->first('logo') }}</span>
                                @endif
                            </div>
                        </div>
                        <footer class="panel-footer mt-lg">
                            <div class="row">
                                <div class="col-md-2 col-md-offset-3">
                                    <button type="submit" class="btn btn-default btn-block" id="edit_university_submit">
                                        <i class="fas fa-plus-circle"></i> Update								
                                    </button>
                                </div>
                            </div>
                        </footer>
                    </form>
                </div>
            </div>
        </div>
    </section>
 </section>


@endsection
@section('js')
<script>

    $(document).ready(function(){
        $(document).on('click','#edit_university_submit',function(e){
            // e.preventDefault(); 
            $(this).text("Updating...");
            var u_id = $('#edit_university_id').val();
            var data = {
                'university_name': $('#edit_university_name').val(),
                'college_name': $('#edit_college_name').val(),
                'email': $('#edit_email').val(),
                'mobile': $('#edit_mobile').val(), 
                'city': $('#edit_city').val(), 
                'state': $('#edit_state').val(), 
                'link': $('#edit_link').val(), 
                'logo': $('#edit_logo').val(), 
                'address': $('#edit_address').val(), 
                'id': $('#edit_university_id').val(), 
                
            }
            $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
            });
            $.ajax({
                type:"PATCH",
                url:"{{url('super-admin/universities')}}/"+u_id,
                data:data,
                dataTable:"json",
                success: function(response){

                    if(response.status == 400)
                     {

                        if(response.errors.university_name){
                            $('.university_name_error').html(`<span class="text-danger">${response.errors.university_name}</span>`)

                        }
                        if(response.errors.college_name){
                            $('.college_name_error').html(`<span class="text-danger">${response.errors.college_name}</span>`)
                            console.log("test1");

                        }
                        if(response.errors.email){
                            $('.email_error').html(`<span class="text-danger">${response.errors.email}</span>`)
                            console.log("test1");

                        }
                        if(response.errors.mobile){
                            $('.mobile_error').html(`<span class="text-danger">${response.errors.mobile}</span>`)
                            console.log("test1");

                        }
                        
                        if(response.errors.city){
                            $('.city_error').html(`<span class="text-danger">${response.errors.city}</span>`)
                            console.log("test1");

                        }
                        
                        if(response.errors.state){
                            $('.state_error').html(`<span class="text-danger">${response.errors.state}</span>`)
                            console.log("test1");

                        }
                        
                        if(response.errors.address){
                            $('.address_error').html(`<span class="text-danger">${response.errors.address}</span>`)
                            console.log("test1");

                        }
                        $('#edit_university_submit').text('Update')
                       
                     }
                     else
                     {
                        $('#edit_university_submit').text('Updated')
                        $('.error_div').html('');
                        toastr.options =
                        {
                            "closeButton" : true,
                            "progressBar" : true,
                            "positionClass": "toast-top-right"
                        }
                        toastr.success(response.message);
                        setTimeout(function() {
                            window.location.href = response.data.goto = "{{url('super-admin/universities')}}";
                            // location.reload();
                            
                        }, 1000);
                        
                        
                     }
                }
            });
        });

    });
</script>


@endsection



