<header id="header-panel" class="position-fixed top-0 w-100 bg-white z-depth-1 px-lg-4 d-flex align-items-center" style="z-index: 1;">
    <div class="container-fluid">
        <div class="row g-3">
            <div class="col-12 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <div class="me-3 fs-1 d-flex align-items-center mt-1 cursor-pointer d-lg-none" data-bs-toggle="offcanvas" href="#offcanvasMobile" role="button" aria-controls="offcanvasMobile">
                        <i class="bi bi-list"></i>
                    </div>

                    <!-- logo -->
                    <a href="" class="text-decoration-none">
                        <img src="assets/images/logo.png" class="img-fluid d-none d-lg-block" alt="logo">
                        <img src="assets/images/mobile-logo.png" class="img-fluid d-lg-none" alt="logo">
                    </a>
                </div>

                <div class="dropdown">
                    <button class="btn btn-link d-flex align-items-center text-dark text-decoration-none dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <div class="me-2">Hello, <?php echo e(auth()->user()->name); ?></div>
                        <img src="assets/images/avatar.png" class="img-fluid rounded-circle border border-success border-2 dropdown-avatar" alt="">
                    </button>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item d-flex" href="#">
                                <div class="me-3"><i class="bi bi-speedometer2"></i></div>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item d-flex" href="#">
                                <div class="me-3"><i class="bi bi-file-earmark-text"></i></div>
                                <span>Invoices</span>
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item d-flex" href="#">
                                <div class="me-3"><i class="bi bi-file-earmark-plus"></i></div>
                                <span>Publish New Project</span>
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item d-flex" href="#">
                                <div class="me-3"><i class="bi bi-pencil-square"></i></div>
                                <span>Edit Profile</span>
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item d-flex" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                <div class="me-3"><i class="bi bi-box-arrow-right"></i></div>
                                <span>Logout</span>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                                </form>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Offcanvas -->
    <div class="offcanvas offcanvas-start text-bg-dark" tabindex="-1" id="offcanvasMobile" aria-labelledby="offcanvasMobileLabel">
        <div class="offcanvas-header">
            <!-- logo -->
            <a href="" class="text-decoration-none">
                <img src="assets/images/mobile-logo.png" class="img-fluid d-lg-none" alt="logo">
            </a>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
        <?php echo $__env->make('contractor.includes.sidebar-menu-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</header><?php /**PATH E:\laravel-xpostands\resources\views/contractor/includes/header.blade.php ENDPATH**/ ?>