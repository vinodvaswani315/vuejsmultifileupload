<div class="container-fluid">
    <div class="row g-3">
        <div class="col-12 mb-5">
            <div class="card rounded-5 bg-light border-0">
                <div class="badge rounded-5 position-absolute top-0 end-0 text-bg-success fs-6 px-4 mt-2 me-3 py-2">Active</div>
                <div class="card-body py-md-5">
                    <div class="row">
                        <div class="col-md-10 mx-auto">
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <img src="assets/images/avatar.png" class="img-fluid rounded-circle border border-success border-2 p-md-1 user-image" alt="">
                                </div>
                                <div class="col-md-9">
                                    <div class="d-flex justify-content-between">
                                        <div class="fs-1 d-flex">
                                        {{ auth()->user()->name }}
                                            <div class="ms-4 text-primary"><i class="bi bi-shield-fill-check"></i></div>
                                        </div>

                                        <button type="button" class="ms-3 btn btn-light rounded-circle bg-white d-flex justify-content-center align-items-center p-0 hoverable text-muted editor-btn">
                                            <i class="bi bi-pencil-fill"></i>
                                        </button>
                                    </div>
                                    <div class="mt-0">
                                        <a href="mailto:steve@gmail.com" class="text-decoration-none fs-5 text-muted">{{ auth()->user()->email }}</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- <div class="col-12">
            <div class="row g-3">
                <div class="col-6 col-md-3 mb-5">
                    <div class="card border-success rounded-4 h-100">
                        <div class="position-absolute w-100 text-success display-5 card-badge d-flex justify-content-center">
                            <span class="bg-white rounded-circle">
                                <i class="bi bi-check-circle-fill"></i>
                            </span>
                        </div>
                        <div class="card-body pt-4 pt-sm-5 pt-lg-5">
                            <div class="text-center fw-bold mb-2">My Profile</div>
                            <div class="text-center text-muted">Today, with our Loram Technologies business group with our</div>
                        </div>
                    </div>
                </div>

                <div class="col-6 col-md-3 mb-5">
                    <div class="card border-success rounded-4 h-100">
                        <div class="position-absolute w-100 text-success display-5 card-badge d-flex justify-content-center">
                            <span class="bg-white rounded-circle">
                                <i class="bi bi-check-circle-fill"></i>
                            </span>
                        </div>
                        <div class="card-body pt-4 pt-sm-5 pt-lg-5">
                            <div class="text-center fw-bold mb-2">My Brand</div>
                            <div class="text-center text-muted">Today, with our Loram Technologies business group with our</div>
                        </div>
                    </div>
                </div>

                <div class="col-6 col-md-3 mb-5">
                    <div class="card border-success rounded-4 h-100">
                        <div class="position-absolute w-100 text-success display-5 card-badge d-flex justify-content-center">
                            <span class="bg-white rounded-circle">
                                <i class="bi bi-check-circle-fill"></i>
                            </span>
                        </div>
                        <div class="card-body pt-4 pt-sm-5 pt-lg-5">
                            <div class="text-center fw-bold mb-2">Reviews</div>
                            <div class="text-center text-muted">Today, with our Loram Technologies business group with our</div>
                        </div>
                    </div>
                </div>

                <div class="col-6 col-md-3 mb-5">
                    <div class="card border-danger rounded-4 h-100">
                        <div class="position-absolute w-100 text-danger display-5 card-badge d-flex justify-content-center">
                            <span class="bg-white rounded-circle">
                                <i class="bi bi-exclamation-circle-fill"></i>
                            </span>
                        </div>
                        <div class="card-body pt-4 pt-sm-5 pt-lg-5">
                            <div class="text-center text-danger fw-bold mb-2">Add Projects</div>
                            <div class="text-center text-muted">Today, with our Loram Technologies business group with our</div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->

        <div class="col-12">
            <div class="row g-3">
                <div class="col-6 col-md-3 mb-5">
                    <div class="card border-success rounded-4 h-100">
                        <div class="position-absolute w-100 text-success display-5 card-badge d-flex justify-content-center">
                            <span class="bg-white rounded-circle">
                                <i class="bi bi-check-circle-fill"></i>
                            </span>
                        </div>
                        <div class="card-body pt-4 pt-sm-5 pt-lg-5">
                            <div class="text-center fw-bold mb-2">My Profile</div>
                            <div class="text-center text-muted">Today, with our Loram Technologies business group with our</div>
                        </div>
                    </div>
    <div class="mt-3 progress" style="
    width: 83%;
    margin: 0 auto;
">
  <div class="progress-bar bg-success" role="progressbar" style="width: 100%;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div>
                </div>

                <div class="col-6 col-md-3 mb-5">
                    <div class="card border-success rounded-4 h-100">
                        <div class="position-absolute w-100 text-warning  display-5 card-badge d-flex justify-content-center">
                            <span class="bg-white rounded-circle">
                                <i class="bi bi-exclamation-circle-fill"></i>
                            </span>
                        </div>
                        <div class="card-body pt-4 pt-sm-5 pt-lg-5">
                            <div class="text-center fw-bold mb-2">My Brand</div>
                            <div class="text-center text-muted">Today, with our Loram Technologies business group with our</div>
                        </div>
                    </div>
    <div class="mt-3 progress" style="
    width: 83%;
    margin: 0 auto;
">
  <div class="progress-bar bg-warning" role="progressbar" style="width: 45%;" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100">55%</div>
</div>
                </div>

                <div class="col-6 col-md-3 mb-5">
                    <div class="card border-success rounded-4 h-100">
                        <div class="position-absolute w-100 text-primary display-5 card-badge d-flex justify-content-center">
                            <span class="bg-white rounded-circle">
                                <i class="bi bi-exclamation-circle-fill"></i>
                            </span>
                        </div>
                        <div class="card-body pt-4 pt-sm-5 pt-lg-5">
                            <div class="text-center fw-bold mb-2">Reviews</div>
                            <div class="text-center text-muted">Today, with our Loram Technologies business group with our</div>
                        </div>
                    </div>
    <div class="mt-3 progress" style="
    width: 83%;
    margin: 0 auto;
">
  <div class="progress-bar" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">75%</div>
</div>
                </div>

                <div class="col-6 col-md-3 mb-5">
                    <div class="card border-danger rounded-4 h-100">
                        <div class="position-absolute w-100 text-danger display-5 card-badge d-flex justify-content-center">
                            <span class="bg-white rounded-circle">
                                <i class="bi bi-exclamation-circle-fill"></i>
                            </span>
                        </div>
                        <div class="card-body pt-4 pt-sm-5 pt-lg-5">
                            <div class="text-center text-danger fw-bold mb-2">Add Projects</div>
                            <div class="text-center text-muted">Today, with our Loram Technologies business group with our</div>
                        </div>
                    </div>
    <div class="mt-3 progress" style="
    width: 83%;
    margin: 0 auto;
">
  <div class="progress-bar bg-danger" role="progressbar" style="width: 25%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%</div>
</div>
                </div>
            </div>
        </div>
        
        <div class="col-12 mb-5">
            <div class="row">
                <div class="col-md-10 mx-auto">
                    <div class="alert alert-warning text-center lead rounded-4" role="alert">
                        <span class="text-black">Contractors who complete these get</span> <span class="text-danger fw-bold">20% more leads.</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- ////////////// dashboard /////////////// -->
        <div class="col-12 mb-5">
            <div class="row g-3 mb-4">
                <div class="col-6">
                    <div class="fs-4 fw-bold text-uppercase d-flex flex-column">
                        <div>dashboard</div>
                        <div class="border-bottom border-primary border-3 mt-2" style="width: 50px;"></div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="d-flex justify-content-end w-100">
                        <button type="button" class="btn btn-warning text-uppercase rounded-pill px-4">History <i class="bi bi-chevron-right"></i></button>
                    </div>
                </div>
            </div>

            <div class="row g-3">
                <div class="col-sm-6 col-md-4">
                    <div class="card border-primary h-100">
                        <div class="card-header bg-primary text-white fw-bold text-center">
                            Package Details
                        </div>
                        <div class="card-body text-center mb-1">
                            <h5 class="card-title">Package: Basic</h5>
                            <h6><span class="badge text-bg-success text-uppercase">Active</span></h6>
                            <h6 class="mb-0"><small>Total Leads Creadits: 5</small></h6>
                        </div>
                        <div class="card-footer border-0 bg-white">
                            <canvas id="package-detail" style="width:100%;max-width:100%"></canvas>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="card border-primary h-100">
                        <div class="card-header bg-primary text-white fw-bold text-center">
                            Leads Refund Details
                        </div>
                        <div class="card-body text-center mb-1">
                            <h5 class="card-title">Total Accepted: 2</h5>
                            <h6 class="mb-0"><small>(0 Refund)</small></h6>
                        </div>
                        <div class="card-footer border-0 bg-white">
                            <canvas id="lead-refund" style="width:100%;max-width:100%"></canvas>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="card border-primary h-100">
                        <div class="card-header bg-primary text-white fw-bold text-center">
                            Cunsumtion Details
                        </div>
                        <div class="card-body text-center mb-1">
                            <h5 class="card-title">3 Received</h5>
                            <h6 class="mb-0"><small>(2 Accepted)</small></h6>
                        </div>
                        <div class="card-footer border-0 bg-white">
                            <canvas id="cunsumtion-details" style="width:100%;max-width:100%"></canvas>
                        </div>
                        <div class="card-footer border-0 bg-white text-center">
                            <small><i class="bi bi-circle-fill text-danger"></i> 0 Expired</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ////////////// New Leads /////////////// -->
        <div class="col-12 mb-5">
            <div class="row g-3">
                <div class="col-12 mb-3">
                    <div class="fs-4 fw-bold text-uppercase d-flex flex-column">
                        <div>New Leads (unattended)</div>
                        <div class="border-bottom border-primary border-3 mt-2" style="width: 50px;"></div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead class="table-primary">
                                <tr>
                                    <th scope="col" class="w-25">Lead No.</th>
                                    <th scope="col" class="w-25">City</th>
                                    <th scope="col" class="w-25">Trade Show</th>
                                    <th scope="col" class="w-25">Badget</th>
                                    <th scope="col" class="w-25"></th>
                                </tr>
                            </thead>
                            <tbody class="table-group-divider">
                                <?php for ($i = 0; $i < 5; $i++) { ?>
                                    <tr>
                                        <th scope="row">#2071</th>
                                        <td>Mark</td>
                                        <td>Otto</td>
                                        <td>@mdo</td>
                                        <td>
                                            <span class="badge text-bg-primary text-uppercase text-white ">Accepted</span>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-12">
                    <nav class="w-100 d-flex justify-content-center mb-0">
                        <ul class="pagination justify-content-end">
                            <li class="page-item disabled">
                                <a class="page-link"><i class="bi bi-chevron-double-left"></i> Previous</a>
                            </li>

                            <li class="page-item">
                                <a class="page-link" href="#">Next <i class="bi bi-chevron-double-right"></i></a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>

        <!-- ////////////// Discarded Leads /////////////// -->
        <div class="col-12 mb-5">
            <div class="row g-3">
                <div class="col-12 mb-3">
                    <div class="fs-4 fw-bold text-uppercase d-flex flex-column">
                        <div>Discarded Leads</div>
                        <div class="border-bottom border-primary border-3 mt-2" style="width: 50px;"></div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead class="table-primary">
                                <tr>
                                    <th scope="col" class="w-25">Lead No.</th>
                                    <th scope="col" class="w-25">City</th>
                                    <th scope="col" class="w-25">Trade Show</th>
                                    <th scope="col" class="w-25">Badget</th>
                                    <th scope="col" class="w-25"></th>
                                </tr>
                            </thead>
                            <tbody class="table-group-divider">
                                <tr>
                                    <td colspan="5" class="text-center">
                                        You haven't discarded any leads yet
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-12">
                    <nav class="w-100 d-flex justify-content-center mb-0">
                        <ul class="pagination justify-content-end">
                            <li class="page-item disabled">
                                <a class="page-link"><i class="bi bi-chevron-double-left"></i> Previous</a>
                            </li>

                            <li class="page-item">
                                <a class="page-link" href="#">Next <i class="bi bi-chevron-double-right"></i></a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>

        <!-- ////////////// Expired Leads /////////////// -->
        <div class="col-12 mb-5">
            <div class="row g-3">
                <div class="col-12 mb-3">
                    <div class="fs-4 fw-bold text-uppercase d-flex flex-column">
                        <div>Expired Leads (UNATTENDED)</div>
                        <div class="border-bottom border-primary border-3 mt-2" style="width: 50px;"></div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead class="table-primary">
                                <tr>
                                    <th scope="col" class="w-25">Lead No.</th>
                                    <th scope="col" class="w-25">City</th>
                                    <th scope="col" class="w-25">Trade Show</th>
                                    <th scope="col" class="w-25">Badget</th>
                                    <th scope="col" class="w-25"></th>
                                </tr>
                            </thead>
                            <tbody class="table-group-divider">
                                <tr>
                                    <th scope="row">#2071</th>
                                    <td></td>
                                    <td></td>
                                    <td>---</td>
                                    <td>
                                        <span class="badge text-bg-danger text-uppercase text-white ">Expired</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-12">
                    <nav class="w-100 d-flex justify-content-center mb-0">
                        <ul class="pagination justify-content-end">
                            <li class="page-item disabled">
                                <a class="page-link"><i class="bi bi-chevron-double-left"></i> Previous</a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <!-- <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li> -->
                            <li class="page-item">
                                <a class="page-link" href="#">Next <i class="bi bi-chevron-double-right"></i></a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>