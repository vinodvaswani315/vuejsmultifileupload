<footer id="footer" class="footer">
</footer>
  <?php /**PATH E:\laravel-xpostands\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>