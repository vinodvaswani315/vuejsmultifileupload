<!doctype html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <?php echo $__env->make('frontend.includes.commoncss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/contractor-signup.min.css')); ?>">
    <title>Contractor Signup</title>
</head>

<body class="d-flex flex-column h-100">
<router-view></router-view>
    <!-- BEGIN: HEADER PANEL -->
    <?php echo $__env->make('frontend.includes.secondryheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: HEADER PANEL -->

    <main class="add-secondary-header" id="signup-panel">
        <section class="hero-section py-4">
            <div class="container-fluid container-sm">
                <div class="row g-3" id="signupFormApp">
                    <form id="signupForm" action="contractor-signup" class="needs-validation" @submit.prevent="onSubmit" method="post">
                    <?php echo e(csrf_field()); ?>

                        <div class="col-md-12">
                            <div class="fs-3 mb-0 text-center">Create a Free Account</div>
                            <div class="lead mb-4 text-center">Please fill in below form to create an account with us.</div>
                        </div>
                        <div class="col-md-10 mx-auto">
                            <div class="position-relative m-4">
                                <div class="progress" style="height: 1px;">
                                    <div class="progress-bar" role="progressbar" aria-label="Progress" style="width: 0%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <button type="button" class="position-absolute top-0 start-0 translate-middle btn btn-sm rounded-pill" :class="{'text-white btn-primary':step==1,'btn-secondary':step!=1}" style="width: 2rem; height:2rem;">1</button>
                                <button type="button" class="position-absolute top-0 start-50 translate-middle btn btn-sm rounded-pill" :class="{'text-white btn-primary':step==2,'btn-secondary':step!=2}" style="width: 2rem; height:2rem;">2</button>
                                <button type="button" class="position-absolute top-0 start-100 translate-middle btn btn-sm rounded-pill" :class="{'text-white btn-primary':step==3,'btn-secondary':step!=3}" style="width: 2rem; height:2rem;">3</button>
                            </div>
                        </div>

                        <div class="col-lg-8 col-xl-6 mx-auto" :class="{'d-block': step==1, 'd-none': step!=1}">
                            <div class="row g-3">
                                <div class="col-md-12">
                                    <div class="h4 text-primary fw-bold w-100">Personal Details</div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" ref="first_name" v-model="formData.first_name" id="first_name" placeholder="Your Name">
                                        <div class="invalid-feedback">
                                        Please enter first name.
                                        </div>
                                        <label for="first_name">First Name</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" ref="last_name" v-model="formData.last_name" id="last_name" placeholder="Your Name">
                                        <div class="invalid-feedback">
                                        Please enter last name.
                                        </div>
                                        <label for="last_name">Last Name</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" ref="email" v-model="formData.email" id="email" placeholder="Your Name">
                                        <div class="invalid-feedback">
                                        Please enter E-mail.
                                        </div>
                                        <label for="email">E-Mail Id</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" ref="contact_number" v-model="formData.contact_number" id="contact_number" placeholder="Contact Number">
                                        <label for="contact_number">Contact Number</label>
                                    </div>
                                    <small>Fill the contact number with country code</small>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-floating">
                                        <input type="password" class="form-control" ref="password" v-model="formData.password" id="password" placeholder="Your Name">
                                        <div class="invalid-feedback">
                                        Please enter password.
                                        </div>
                                        <label for="password">Password</label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-8 col-xl-6 mx-auto" :class="{'d-block': step==2, 'd-none': step!=2}">
                            <div class="row g-3">
                                <div class="col-md-12">
                                    <div class="h4 text-primary fw-bold w-100">Company Details</div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" ref="company_name" v-model="formData.company_name" id="company_name" placeholder="Company Name">
                                        <div class="invalid-feedback">
                                        Please enter E-mail.
                                        </div>
                                        <label for="company_name">Company Name</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="floatingInput" placeholder="Your Name">
                                        <label for="floatingInput">Website URL</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <select class="form-select" id="floatingSelect" aria-label="Floating label select example">
                                            <option selected>Open this select menu</option>
                                            <option value="1">One</option>
                                            <option value="2">Two</option>
                                            <option value="3">Three</option>
                                        </select>
                                        <label for="floatingSelect">Select Country</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <select class="form-select" id="floatingSelect" aria-label="Floating label select example">
                                            <option selected>Open this select menu</option>
                                            <option value="1">One</option>
                                            <option value="2">Two</option>
                                            <option value="3">Three</option>
                                        </select>
                                        <label for="floatingSelect">Select City</label>
                                    </div>
                                    <small>Select a country to load cities list</small>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-floating">
                                        <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea"></textarea>
                                        <label for="floatingTextarea">Address</label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-8 col-xl-10 mx-auto" :class="{'d-block': step==3, 'd-none': step!=3}">
                            <div class="row g-3">
                                <div class="col-md-12">
                                    <div class="h4 text-primary fw-bold w-100 mb-0">Select Areas of Intervention</div>
                                </div>
                                <div class="col-12">
                                    <div class="accordion mt-4" id="accordionFlushExample">
                                    <template v-for="(item,index) in continents">
                                            <div class="accordion-item border-0 z-depth-1 hoverable mb-3 rounded-3">
                                                <h2 class="accordion-header" :id="'flush-heading'+item.code">
                                                    <button class="accordion-button rounded-3 fs-5" type="button" data-bs-toggle="collapse" :data-bs-target="'#flush-collapse'+item.code" aria-expanded="true" :aria-controls="'flush-collapse'+item.code">
                                                        {{item.name}} ({{item.countries.length}})
                                                    </button>
                                                </h2>
                                                <div :id="'flush-collapse'+item.code" class="accordion-collapse collapse" :class="{'show': index==0}" :aria-labelledby="'flush-heading'+item.code" data-bs-parent="#accordionFlushExample">
                                                    <div class="accordion-body">
                                                        <div class="row g-3 overflow-auto" style="max-height: 200px;">
                                                            
                                                            <template v-if="item.countries.length">
                                                                <div class="col-sm-6 col-md-4" v-for="country in item.countries">
                                                                    <div class="form-check">
                                                                        <input class="form-check-input" type="checkbox" v-model="formData.countries" :value="country.country_id" :id="'flexCheckDefault'+country.country_id">
                                                                        <label class="form-check-label" :for="'flexCheckDefault'+country.country_id">
                                                                            {{country.name}}
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                            </template>
                                                        
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </template>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 d-flex justify-content-center align-items-center mt-5">
                        <ul class="list-inline mb-0">

                                <li v-show="step>1" class="list-inline-item">
                                    <a @click.prevent="prevStep" class="btn btn-dark text-white rounded-pill px-4">
                                        <i class="bi bi-arrow-left me-1"></i> Previous
                                    </a>
                                </li>
                                
                                <li v-show="step<3" class="list-inline-item">
                                    <a @click.prevent="nextStep" class="btn btn-primary text-white rounded-pill px-4">
                                        Next <i class="bi bi-arrow-right ms-1"></i>
                                    </a>
                                </li>

                                <li v-show="step==3" class="list-inline-item">
                                    <a @click.prevent="onSubmit" class="btn btn-primary text-white rounded-pill px-4">
                                        Sunmit <i class="bi bi-arrow-right ms-1"></i>
                                    </a>
                                </li>

                            </ul>
                        </div>
                    </form>
                </div>
            </div>
        </section>

        <section class="bg-white py-5">
            <div class="container-fluid container-sm">
                <div class="row g-3">
                    <div class="col-sm-8">
                        <div class="fw-bold text-primary fs-4">Ask for 5 Free Quotations for your Exhibition Stands or Contact Us for more information:</div>
                        <div class="display-4">+31 20 8080653</div>
                    </div>
                    <div class="col-sm-4">
                        <img src="<?php echo e(asset('frontend/images/headphone.png')); ?>" class="img-fluid" alt="">
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- BEGIN: FOOTER PANEL -->
    <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: FOOTER PANEL -->
    
    <?php echo $__env->make('frontend.includes.commonJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script>
        
    axios.defaults.headers.common = {
    'X-CSRF-TOKEN' : document.querySelector('meta[name="csrf-token"]').getAttribute('content')
    };
    
    createApp({
    data() {
        return {
            step: 1,
            formData:{
                onlyValidate: true,
                validateAndSunmit:false,
                step: 0,
                countries:[]
            },
            continents:[],
            enquiryData:{

            }
        }
    },
    mounted(){
        this.loadContinents()
    },
    methods:{
        nextStep()
        {   
            this.onSubmit();
        },
        prevStep(){
            this.step = this.step - 1;
        },
        onSubmit()
        {

            $(".is-invalid").removeClass('is-invalid')

            if(this.step==3)
            {
                this.formData.onlyValidate = false
                this.formData.validateAndSunmit = true                
            }
           
            this.formData.step = this.step

            axios.post("contractor-signup", this.formData).then(function (response) {
                
                if(response.data.status=='success')
                {
                    window.location.href = response.data.goto
                }
                
            }).catch((errors)=>{
                
                this.loading = false;
                
                this.step = errors.response.data.goto_step
                
                $(".is-invalid").removeClass('is-invalid')
                Object.keys(errors.response.data.error).forEach((key,index)=>
                {

                    var el = this.$refs[key];
                    el.classList.remove("is-invalid");
                    el.classList.add("is-invalid");
                    el.nextElementSibling.innerText = errors.response.data.error[key][0]

                    if(index==0)
                    {
                        el.scrollIntoView({
                            behavior: "smooth",
                            block: "end",
                            inline: "nearest",
                        });
                    }
                })
                
            });
        },
        saveEnquiry(){
            axios.post("save-enquiry", this.enquiryData).then(function (response) {
                
                if(response.data.status=='success')
                {
                    window.location.href = response.data.goto
                }
                
            }).catch((errors)=>{
                
                this.loading = false;
                
                $(".is-invalid").removeClass('is-invalid')
                Object.keys(errors.response.data.error).forEach((key,index)=>
                {
                    var el = this.$refs[key]
                    el.classList.remove("is-invalid")
                    el.nextElementSibling.innerHTML = errors.response.data.error[key][0]
                    el.classList.add("is-invalid")

                    if(index==0)
                    {
                        el.scrollIntoView({
                            behavior: "smooth",
                            block: "end",
                            inline: "nearest",
                        });
                    }
                })
                
            });
        },
        loadContinents()
        {
            axios.get("api/continents-countries").then((response)=>{

                this.continents = response.data

            }).catch(()=>{


            })
            
        }
    }
    }).mount('#signupFormApp')
</script>
</body>

</html><?php /**PATH E:\laravel-xpostands\resources\views/frontend/contractor-signup.blade.php ENDPATH**/ ?>