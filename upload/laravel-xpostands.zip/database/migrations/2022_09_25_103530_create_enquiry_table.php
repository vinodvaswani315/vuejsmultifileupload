<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('enquiries', function (Blueprint $table) {
            $table->id();
            $table->string("contact_person_name")->nullable();
            $table->string("email")->nullable();
            $table->string("contact_number")->nullable();
            $table->string("event_name")->nullable();
            $table->string("event_city")->nullable();
            $table->string("event_details")->nullable();
            $table->enum('own_space', ['yes', 'no'])->default('yes');
            $table->string('estimate_from')->nullable();
            $table->string('estimate_to')->nullable();
            $table->enum('estimate_currency', ['dollar', 'euro'])->default('dollar');
            $table->string('stand_size')->nullable();
            $table->string('stand_size_unit')->nullable();
            $table->string('sent_to_contractors')->nullable();
            $table->string('length')->nullable();
            $table->string('depth')->nullable();
            $table->string('stand_type')->nullable();
            $table->string('show_start')->nullable();
            $table->string('show_end')->nullable();
            $table->string('company')->nullable();
            $table->string('lead_status')->nullable();
            $table->string('attachment_path')->nullable();
            $table->string('website')->nullable();
            $table->string('event_country')->nullable();
            $table->enum('service_need', ['need-stand', 'already-have-stand'])->default('need-stand');
            $table->string('country')->nullable();
            $table->string('phonecode')->nullable();
            $table->string('service_element')->nullable();
            $table->string('price')->nullable();
            $table->string('enquiry_type')->nullable();
            $table->string('comment_history')->nullable();
            $table->string('archive_status')->nullable();
            $table->string('xpostand_comment')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('enquiries');
    }
};
