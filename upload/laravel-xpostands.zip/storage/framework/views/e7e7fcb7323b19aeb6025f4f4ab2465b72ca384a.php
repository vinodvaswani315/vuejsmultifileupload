<section id="sidebar-panel" class="bg-dark position-fixed top-0 start-0 text-white d-none d-lg-block">
    <div class="px-4 py-5 overflow-auto w-100 h-100 side-scroll">
    <?php echo $__env->make('contractor.includes.sidebar-menu-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section><?php /**PATH D:\projects\project\resources\views/contractor/includes/sidebar.blade.php ENDPATH**/ ?>