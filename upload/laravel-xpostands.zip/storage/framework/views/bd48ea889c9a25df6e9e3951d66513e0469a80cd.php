<footer id="footer" class="footer">
</footer>
  <?php /**PATH E:\xpostand\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>