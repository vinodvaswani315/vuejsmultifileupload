<section id="secondary-header-menu" class="custom-fixed-top">
    <div class="bg-dark sh-menu py-1 py-sm-1 py-xl-3 shadow px-lg-5 desktop-box h-100 d-flex align-items-center">
        <div class="container-fluid ">
            <div class="row">
                <div class="col-xl-2 d-flex justify-content-between align-items-center">
                    <a href="/" class="text-decoration-none d-none d-xl-block">
                        <img src="<?php echo e(asset('frontend/images/logo.png')); ?>" class="img-fluid" alt="">
                    </a>

                    <a href="/" class="text-decoration-none d-xl-none">
                        <img src="<?php echo e(asset('frontend/images/mobile-logo-bw.png')); ?>" class="img-fluid position-absolute top-0 start-0" style="width: 52px;" alt="">
                    </a>
                    <!-- <a href="/" class="text-decoration-none d-md-none">
                        <img src="<?php echo e(asset('frontend/images/mobile-logo.png')); ?>" class="img-fluid" alt="">
                    </a> -->

                    <button type="button" class="btn btn-primary d-xl-none rounded-pill text-white px-4 ms-5 ms-sm-0 hoverable">Get a Free Quote</button>

                    <div class="hamburger d-xl-none" onclick="myFunction(this)" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMobile" aria-controls="offcanvasMobile">
                        <div class="bar1"></div>
                        <div class="bar2"></div>
                        <div class="bar3"></div>
                    </div>

                    <!-- <button type="button" class="btn d-xl-none btn-link text-decoration-none text-dark fs-1" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMobile" aria-controls="offcanvasMobile"><i class="bi bi-list"></i></button> -->
                </div>
                <div class="col-sm-10 d-none d-xl-flex justify-content-end align-items-center">
                    <ul class="list-inline d-flex align-items-center mb-0">
                        <li class="list-inline-item">
                            <button type="button" class="btn btn-primary rounded-pill text-white px-1 px-sm-3 hoverable">I am an Exhibitor</button>
                        </li>
                        <li class="list-inline-item">
                            <button type="button" class="btn btn-outline-primary rounded-pill px-1 px-sm-3 hoverable">I am Stand Contractor</button>
                        </li>
                        <li class="list-inline-item">
                            <button type="button" class="btn btn-link text-decoration-none text-dark fw-bold" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>
                        </li>
                        <li class="list-inline-item ms-md-3 d-none d-sm-block d-lg-none">
                            <button type="button" class="btn btn-link text-decoration-none text-primary fs-1" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMobile" aria-controls="offcanvasMobile"><i class="bi bi-list text-primary"></i></button>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-black d-none d-xl-block desktop-menu">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <ul class="list-inline d-flex justify-content-start align-items-center mb-0">
                        <li class="nav-item logo-item logo-animation">
                            <a href="/" class="text-decoration-none home-page-logo">
                                xpo
                            </a>
                        </li>
                        <?php echo $__env->make('frontend.includes.primary-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Offcanvas -->
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasMobile" aria-labelledby="offcanvasMobileLabel">
        <!-- <div class="offcanvas-header bg-white">
            <a href="/" class="text-decoration-none">
                <img src="<?php echo e(asset('frontend/images/logo.png')); ?>" class="img-fluid" alt="">
            </a>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div> -->
        <div class="offcanvas-body d-md-flex justify-content-md-center align-items-md-center pt-5">
            <div class="w-100">
                <ul class="list-inline d-flex flex-column mb-3">
                    <li class="list-inline-item d-flex justify-content-center mb-3">
                        <button type="button" class="btn btn-light rounded-pill drawer-btn hoverable">I am an Exhibitor</button>
                    </li>
                    <li class="list-inline-item d-flex justify-content-center">
                        <button type="button" class="btn btn-outline-light rounded-pill drawer-btn hoverable">I am Stand Contractor</button>
                    </li>
                </ul>
                <ul class="nav flex-column justify-content-center mb-4">
                    <?php echo $__env->make('frontend.includes.primary-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </ul>
                <ul class="list-inline d-flex flex-column mb-3">
                    <li class="list-inline-item d-flex justify-content-center mb-3">
                        <button type="button" class="btn btn-light rounded-pill drawer-btn hoverable text-uppercase">Login</button>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>
<?php echo $__env->make('frontend.includes.login-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\project\resources\views/frontend/includes/secondryheader.blade.php ENDPATH**/ ?>