<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>F.A.Q ?</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <?php echo $__env->make('admin.includes.common-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.4.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- ======= Header Ends ======= -->
  
  <!-- ======= Sidebar ======= -->
  <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Faqs</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
          <li class="breadcrumb-item active">Faqs</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

        <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> <?php echo e(Session::get('success')); ?>.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

          <div class="card">
            <div class="card-body">
              <!-- <h5 class="card-title">Table with stripped rows</h5> -->

              <div class="d-flex flex-row-reverse">
                <a type="button" class="btn btn-primary my-3" href="<?php echo e(url('superadmin/faqs/new')); ?>">
                <i class="bi bi-plus-circle-fill me-1"></i> Add Faq</a>
              </div>

              <!-- Table with stripped rows -->
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Position</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($item->id); ?></th>
                    <td><?php echo e($item->question); ?></td>
                    <td><?php echo e($item->answer); ?></td>
                    <td>
                    
                    
                    
                    <form class="d-flex" id="delete-form-<?php echo e($item->id); ?>" action="<?php echo e(url('superadmin/faqs/destroy/'.$item->id)); ?>" method="post">
                      <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                      <a href="<?php echo e(url('superadmin/faqs/'.$item->id.'/edit')); ?>" type="button" class="btn btn-sm btn-primary me-1"><i class="bi bi-pencil-square"></i></a>
                      <button type="submit" class="btn btn-sm btn-danger"><i class="bi bi-trash3-fill"></i></button>
                    </form>
                    
                    
                  </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->
              
              <?php echo e($faqs->links()); ?>

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

 <!-- ======= Footer ======= -->
 <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <?php echo $__env->make('admin.includes.common-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH E:\laravel-xpostands\resources\views/admin/faqs.blade.php ENDPATH**/ ?>