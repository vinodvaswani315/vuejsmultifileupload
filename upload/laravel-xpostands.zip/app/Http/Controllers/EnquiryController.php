<?php

namespace App\Http\Controllers;

use App\Models\Enquiry;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class EnquiryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $enquiries['enquiries'] = Enquiry::orderBy('created_at', 'desc')->paginate(20);

        // $enquiries['enquiries'] = Enquiry::join('enquiry_elements_junction','enquiries.id','=','enquiry_elements_junction.enquiry_id')->join('stand_elements','enquiry_elements_junction.element_id','=','stand_elements.id')->select('enquiries.*','stand_elements.item_name')->orderBy('enquiries.created_at', 'desc')->paginate(20);

        if(count($enquiries['enquiries']))
        {
            for ($i=0; $i < count($enquiries['enquiries']); $i++)
            // foreach ($enquiries['enquiries'] as $item)
            {

                $elements = DB::table('enquiry_elements_junction')->join('stand_elements','enquiry_elements_junction.element_id','=','stand_elements.id')->select('stand_elements.item_name')->where('enquiry_elements_junction.enquiry_id', $enquiries['enquiries'][$i]->id)->get();

                $enquiries['enquiries'][$i]['elements'] = $elements;
                
            }
        }
        
        return view('admin.enquiries',$enquiries);
    }

    public function enquiry_details($enquiry_id)
    {
        $data['data'] = Enquiry::find($enquiry_id);
        return view('admin.enquiries-details',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'contact_person' => 'required',
            'contact_number' => 'required',
            'email' => 'required'
        ]);

        if ($validator->passes())
        {

            $enquiry = new Enquiry();
            $enquiry->contact_person_name = $request->contact_person;
            $enquiry->contact_number = $request->contact_number;
            $enquiry->email = $request->email;
            $enquiry->save();

            Session::put('enquiry_id', $enquiry->id);

            //Start Send Tour Booking Notification of the Customer
            // Mail::send('mail_notification.bookigTourConfirmation', $mail_data, function($message) use ($user) {
                            
            //     $message->to($user->email)->subject('Confirmation Tour Booking');
                
            //     $message->from('chetu.amitkumar@gmail.com','ByoJeep');
            // });
            //End Send Tour Booking Notification of the Customer


            return response()->json(['status'=>'success','goto'=> '/send-enquiry' ],200);
        }
     
        return response()->json(['error'=>$validator->errors()->toArray()],400);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Enquiry  $enquiry
     * @return \Illuminate\Http\Response
     */
    public function show(Enquiry $enquiry)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Enquiry  $enquiry
     * @return \Illuminate\Http\Response
     */
    public function edit()
    {
        if(!Session::has('enquiry_id'))
        {
            return redirect('/');
        }
        else
        {
            $enquiry_id = Session::get('enquiry_id');
            $data['data'] = Enquiry::find($enquiry_id);
            return view('frontend.send-enquiry',$data);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Enquiry  $enquiry
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Enquiry $enquiry)
    {

        $current_step = $request->step;

        switch ($current_step) {
            case 1:
                $dynamic_validation = [
                    'email'=> 'required'
                ];
                break;
                
            case 2:
                $dynamic_validation = [
                    'company' => 'required',
                    'website' => 'required|url'
                ];
                break;
            
            case 3:
                $dynamic_validation = [
                    'event_country' => 'required',
                    'event_city' => 'required',
                    'event_name' => 'required',
                    'stand_size' => 'required|numeric'
                ];
                break;
            
            default:
                $dynamic_validation = [];
                break;
        }

        $validator = Validator::make($request->all(), $dynamic_validation);

        if($request->onlyValidate)
        {
            if(!$validator->passes())
            {
                return response()->json(['goto_step'=> $current_step ,'error'=>$validator->errors()->toArray()],400);
            }
            else
            {
                return response()->json(['goto_step'=> $current_step+1,'error'=>$validator->errors()->toArray()],400);
            }
        }
        else if($request->validateAndSunmit)
        {
            if($validator->passes())
            {

                $enquiry_id = Session::get('enquiry_id');
                $enquiry = Enquiry::find($enquiry_id);

                $enquiry -> company = $request -> company;
                $enquiry -> website = $request -> website;
                $enquiry -> event_name = $request -> event_name;
                $enquiry -> event_country = $request -> event_country;
                $enquiry -> event_city = $request -> event_city;
                $enquiry -> stand_size = $request -> stand_size;
                $enquiry -> stand_size_unit = $request -> stand_size_unit;
                $enquiry -> service_need = $request -> service_need;
                $enquiry -> own_space = $request -> own_space;
                $enquiry -> estimate_currency = $request -> estimate_currency;
                $enquiry -> price = $request -> price;
                $enquiry -> event_details = $request -> event_details;
                $enquiry ->update();


                $enquiry_id = $enquiry->id;
                
                // Save country id in junction table
                DB::table('enquiry_elements_junction')->where('enquiry_id', $enquiry_id)->delete();  // Remove existing
                if(isset($request->stand_elements) && count($request->stand_elements))
                {
                    foreach($request->stand_elements as $element_id)
                    {
                        DB::insert('insert into enquiry_elements_junction( enquiry_id,element_id) values (?,?)', [$enquiry_id,$element_id]);
                    }
                }

                return response()->json(['status'=>'success','goto'=> '/signup-success'],200);
            }
        }
        else
        {
            return response()->json(['goto_step'=> $current_step,'error'=>$validator->errors()->toArray()],400);
        }

        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Enquiry  $enquiry
     * @return \Illuminate\Http\Response
     */
    public function destroy(Enquiry $enquiry)
    {
        //
    }
}
