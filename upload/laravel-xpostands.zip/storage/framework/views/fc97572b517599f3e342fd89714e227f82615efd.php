<!doctype html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <?php echo $__env->make('frontend.includes.commoncss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/home.min.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />
    <title>Home</title>
</head>

<body class="d-flex flex-column h-100" id="xpoapp">
    <!-- BEGIN: HEADER PANEL -->
    <?php echo $__env->make('frontend.includes.secondryheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: HEADER PANEL -->

    <main class="add-secondary-header" id="home-panel">
        <section class="hero-section py-4" style="background-image: url(frontend/images/form-bg1.jpg);">
            <div class="container-fluid container-sm my-lg-5">
                <div class="row g-3">
                    <div class="col-md-8">
                        <div class="fw-light text-white display-5">GET THE</div>
                        <div class="fw-bold text-primary display-5">5 BEST PROPOSALS</div>
                        <div class="fw-light text-white display-5 mb-4">FOR YOUR EXHIBITION STAND</div>

                        <!-- <div class="text-white fs-3">ABSOLUTELY <span class="text-warning">FREE</span></div>
                        <div class="text-white fs-3 mb-3">WITH NO COMMITMENT</div> -->
                    </div>
                    <div class="col-md-12">
                        <form action="" @submit.prevent="saveEnquiry()">
                        <div class="row g-3">
                            <div class="col-lg-10">
                                <div class="row g-3">
                                    <div class="col-md-3">
                                        <div class="form-floating mb-0">
                                            <input type="text" ref="contact_person" v-model="enquiryData.contact_person" class="form-control bg-transparent text-white" id="floatingInput" placeholder="Your Name">
                                            <div class="invalid-feedback">
                                                Please enter first name.
                                            </div>
                                            <label for="floatingInput" class="text-white">Your Name</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-floating mb-0">
                                            <select v-model="enquiryData.country" class="form-select text-white bg-transparent" id="floatingSelect" aria-label="Floating label select example">
                                                <option selected>Open this select menu</option>
                                                <option value="1">One</option>
                                                <option value="2">Two</option>
                                                <option value="3">Three</option>
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select country.
                                            </div>
                                            <label for="floatingSelect" class="text-white">Country</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-floating mb-0">
                                            <input type="text" ref="contact_number" v-model="enquiryData.contact_number" class="form-control bg-transparent text-white" id="floatingInput" value="+91" placeholder="Your Number">
                                            <div class="invalid-feedback">
                                                Please enter number.
                                            </div>
                                            <label for="floatingInput" class="text-white">Your Number</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-floating mb-0">
                                            <input type="mail" ref="email" v-model="enquiryData.email" class="form-control bg-transparent text-white" id="floatingInput" placeholder="Your E-mail">
                                            <div class="invalid-feedback">
                                                Please enter email.
                                            </div>
                                            <label for="floatingInput" class="text-white">Your E-mail</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 d-flex align-items-center">
                                <button type="submit" class="btn btn-primary btn-lg text-white">Get a Quote</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>

        <section class="bg-dark py-5">
            <div class="container-fluid container-sm">
                <div class="row g-3">
                    <div class="col-lg-10 mx-auto mb-4">
                        <div class="fs-3 fw-bold text-white text-center">HOW IT WORKS?</div>
                    </div>
                    <div class="col-lg-6">
                        <iframe class="w-100 rounded-5 shadow-lg" width="560" height="300" src="https://www.youtube.com/embed/G9hHH0JtRI0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                    <div class="col-lg-6">
                        <iframe class="w-100 rounded-5 shadow-lg" width="560" height="300" src="https://www.youtube.com/embed/G9hHH0JtRI0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </section>

        <section class="bg-white py-5">
            <div class="container-fluid container-sm">
                <div class="row g-3">
                    <div class="col-lg-10 col-xl-6 mx-auto">
                        <div class="fs-3 fw-bold text-center text-uppercase">in which city do you need the stand?</div>
                    </div>
                    <div class="col-12 map-section" style="background-image: url(frontend/images/map-bg.png);">
                        <ul class="list-inline text-center mb-0 mt-4 mt-md-5">
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Amsterdam
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Antwerp
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Athens
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Barcelona
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Berlin
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Bologna
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Bremen
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Brussels
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Cologne
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Dortmund
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Dresden
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Dusseldorf
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Essen
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Florence
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Frankfurt
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Friedrichshafen
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Geneva
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Hamburg
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Hannover
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Helsinki
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Kiev
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Las Vegas
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Leipzig
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> London
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Los Angeles
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Lyon
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Maastricht
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Madrid
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Mannheim
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Marseille
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Miami
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Milan
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Munich
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Nuremberg
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Paris
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Prague
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Rennes
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Rimini
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Rome
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-geo-alt-fill"></i> Rostock
                                </a>
                            </li>
                            <li class="list-inline-item mb-3">
                                <a href="city.php" class="btn btn-primary text-white">
                                    <i class="bi bi-plus-lg"></i> All Cities
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <section class="bg-dark py-5">
            <div class="container-fluid container-sm">
                <div class="row g-3">
                    <div class="col-12 mb-4 text-white">
                        <div class="fs-2 text-center fw-bold">What’s in it for us? Or You?</div>
                        <div class="fw-bold text-center mb-3">Get the best quote for your budget and needs</div>
                    </div>
                    <div class="col-6 col-lg-4">
                        <div class="card border-0 rounded-3 shadow-sm h-100">
                            <div class="card-body">
                                <div class="text-center fs-2 mb-2 text-primary">
                                    <i class="bi bi-percent"></i>
                                </div>
                                <div class="text-center fs-6 fw-bold">Save an average of 23% in your stand:</div>
                                <div class="text-center fs-6">We present the most competitive prices in the market.</div>
                            </div>
                        </div>
                    </div>

                    <div class="col-6 col-lg-4">
                        <div class="card border-0 rounded-3 shadow-sm h-100">
                            <div class="card-body">
                                <div class="text-center fs-2 mb-2 text-primary">
                                    <i class="bi bi-quote"></i>
                                </div>
                                <div class="text-center fs-6 fw-bold">We know what we do</div>
                                <div class="text-center fs-6">We compare more than 250.000 quotes per year.</div>
                            </div>
                        </div>
                    </div>

                    <div class="col-6 col-lg-4">
                        <div class="card border-0 rounded-3 shadow-sm h-100">
                            <div class="card-body">
                                <div class="text-center fs-2 mb-2 text-primary">
                                    <i class="bi bi-lightning"></i>
                                </div>
                                <div class="text-center fs-6 fw-bold">Perfect match</div>
                                <div class="text-center fs-6">The largest stands database in the world and a powerful algorithm.</div>
                            </div>
                        </div>
                    </div>

                    <div class="col-6 col-lg-4">
                        <div class="card border-0 rounded-3 shadow-sm h-100">
                            <div class="card-body">
                                <div class="text-center fs-2 mb-2 text-primary">
                                    <i class="bi bi-coin"></i>
                                </div>
                                <div class="text-center fs-6 fw-bold">Free and without commitment</div>
                                <div class="text-center fs-6">Receive for free the different proposals and choose, or not, one of this quotes.</div>
                            </div>
                        </div>
                    </div>

                    <div class="col-6 col-lg-4">
                        <div class="card border-0 rounded-3 shadow-sm h-100">
                            <div class="card-body">
                                <div class="text-center fs-2 mb-2 text-primary">
                                    <i class="bi bi-clock"></i>
                                </div>
                                <div class="text-center fs-6 fw-bold">Save time</div>
                                <div class="text-center fs-6">In one minute you can ask us what you need.</div>
                            </div>
                        </div>
                    </div>

                    <div class="col-6 col-lg-4">
                        <div class="card border-0 rounded-3 shadow-sm h-100">
                            <div class="card-body">
                                <div class="text-center fs-2 mb-2 text-primary">
                                    <i class="bi bi-building"></i>
                                </div>
                                <div class="text-center fs-6 fw-bold">More than 500 stand builders in your city</div>
                                <div class="text-center fs-6">We compare more than 500 builders for you in each city to get you the top 5.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="lightBlue py-5 article-panel">
            <div class="container-fluid container-sm">
                <div class="row g-3">
                    <div class="col-12 mb-4">
                        <div class="fs-3 fw-bold text-center text-uppercase">
                            Latest published articles
                        </div>
                        <div class="fs-5 text-center text-muted">Here's a list of the latest published articles on Exposands</div>
                    </div>

                    <div class="col-12">
                        <!-- Swiper -->
                        <div class="swiper article-slider">
                            <div class="swiper-wrapper pt-4 pb-5">
                                <!-- <?php for ($i = 0; $i < 10; $i++) { ?>
                                    <div class="swiper-slide px-3">
                                        <a href="" class="text-decoration-none text-dark">
                                            <div class="card border-0 shadow h-100">
                                                <img src="assets/images/Rectangle-25.png" class="card-img-top" alt="...">
                                                <div class="card-body">
                                                    <h5 class="card-title fs-2 mb-3">Experience every facet of the food industry at Fi & Hi India</h5>
                                                    <p class="card-text text-muted">We've been talking with UBM India, the organizers of Food Ingredients & Health Ingredients India, also known as Fi & Hi India, to learn more about the next edition held on October (14-16) in Mumbai.</p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                <?php } ?> -->
                                <div class="swiper-slide px-3">
                                    <a href="" class="text-decoration-none text-dark">
                                        <div class="card border-0 shadow h-100">
                                            <img src="<?php echo e(asset('frontend/images/Rectangle-23.png')); ?>" class="card-img-top" alt="...">
                                            <div class="card-body">
                                                <h5 class="card-title fs-2 mb-3">Experience every facet of the food industry at Fi & Hi India</h5>
                                                <p class="card-text text-muted">We've been talking with UBM India, the organizers of Food Ingredients & Health Ingredients India, also known as Fi & Hi India, to learn more about the next edition held on October (14-16) in Mumbai.</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="swiper-slide px-3">
                                    <a href="" class="text-decoration-none text-dark">
                                        <div class="card border-0 shadow h-100">
                                            <img src="<?php echo e(asset('frontend/images/stand-bg.jpg')); ?>" class="card-img-top" alt="...">
                                            <div class="card-body">
                                                <h5 class="card-title fs-2 mb-3">Experience every facet of the food industry at Fi & Hi India</h5>
                                                <p class="card-text text-muted">We've been talking with UBM India, the organizers of Food Ingredients & Health Ingredients India, also known as Fi & Hi India, to learn more about the next edition held on October (14-16) in Mumbai.</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="swiper-slide px-3">
                                    <a href="" class="text-decoration-none text-dark">
                                        <div class="card border-0 shadow h-100">
                                            <img src="<?php echo e(asset('frontend/images/Rectangle-25.png')); ?>" class="card-img-top" alt="...">
                                            <div class="card-body">
                                                <h5 class="card-title fs-2 mb-3">Experience every facet of the food industry at Fi & Hi India</h5>
                                                <p class="card-text text-muted">We've been talking with UBM India, the organizers of Food Ingredients & Health Ingredients India, also known as Fi & Hi India, to learn more about the next edition held on October (14-16) in Mumbai.</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="swiper-slide px-3">
                                    <a href="" class="text-decoration-none text-dark">
                                        <div class="card border-0 shadow h-100">
                                            <img src="<?php echo e(asset('frontend/images/Rectangle-103.png')); ?>" class="card-img-top" alt="...">
                                            <div class="card-body">
                                                <h5 class="card-title fs-2 mb-3">Experience every facet of the food industry at Fi & Hi India</h5>
                                                <p class="card-text text-muted">We've been talking with UBM India, the organizers of Food Ingredients & Health Ingredients India, also known as Fi & Hi India, to learn more about the next edition held on October (14-16) in Mumbai.</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="swiper-slide px-3">
                                    <a href="" class="text-decoration-none text-dark">
                                        <div class="card border-0 shadow h-100">
                                            <img src="<?php echo e(asset('frontend/images/Rectangle-27.png')); ?>" class="card-img-top" alt="...">
                                            <div class="card-body">
                                                <h5 class="card-title fs-2 mb-3">Experience every facet of the food industry at Fi & Hi India</h5>
                                                <p class="card-text text-muted">We've been talking with UBM India, the organizers of Food Ingredients & Health Ingredients India, also known as Fi & Hi India, to learn more about the next edition held on October (14-16) in Mumbai.</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="swiper-slide px-3">
                                    <a href="" class="text-decoration-none text-dark">
                                        <div class="card border-0 shadow h-100">
                                            <img src="<?php echo e(asset('frontend/images/Rectangle-29.png')); ?>" class="card-img-top" alt="...">
                                            <div class="card-body">
                                                <h5 class="card-title fs-2 mb-3">Experience every facet of the food industry at Fi & Hi India</h5>
                                                <p class="card-text text-muted">We've been talking with UBM India, the organizers of Food Ingredients & Health Ingredients India, also known as Fi & Hi India, to learn more about the next edition held on October (14-16) in Mumbai.</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="swiper-pagination"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="bg-white py-5">
            <div class="container-fluid container-sm">
                <div class="row g-3">
                    <div class="col-lg-6">
                        <div class="fs-3 fw-bold">
                            Any questions?<br> Check out the FAQs
                        </div>
                        <div class="fs-5 mt-3 text-muted mb-4">Still have unanswered questions and need to get in touch?</div>

                        <div class="row g-3">
                            <div class="col-sm-6 col-md-5">
                                <a href="" class="text-decoration-none">
                                    <div class="card card-body">
                                        <div class="text-warning fs-5 mb-2"><i class="bi bi-telephone-fill"></i></div>
                                        <div class="text-dark mb-2">Still have questions?</div>
                                        <div class="text-warning d-flex align-items-center mb-0">Call us <i class="bi bi-arrow-right-short fs-4"></i></div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-sm-6 col-md-5">
                                <a href="" class="text-decoration-none">
                                    <div class="card card-body">
                                        <div class="text-success fs-5 mb-2"><i class="bi bi-chat-dots"></i></div>
                                        <div class="text-dark mb-2">Still have questions?</div>
                                        <div class="text-success d-flex align-items-center mb-0">Call with us <i class="bi bi-arrow-right-short fs-4"></i></div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="accordion mt-4" id="accordionFlushExample">
                            
                            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item border-0 z-depth-1 hoverable mb-3 rounded-3">
                                <h2 class="accordion-header" id="flush-heading<?php echo e($loop->index); ?>">
                                    <button class="accordion-button rounded-3 fs-5" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse<?php echo e($loop->index); ?>" aria-expanded="true" aria-controls="flush-collapse<?php echo e($loop->index); ?>">
                                        <?php echo e($item->question); ?>

                                    </button>
                                </h2>
                                <div id="flush-collapse<?php echo e($loop->index); ?>" class="accordion-collapse collapse <?php if($loop->index ==0): ?> show <?php endif; ?>" aria-labelledby="flush-heading<?php echo e($loop->index); ?>" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body"><?php echo e($item->answer); ?></div>
                                </div>
                            </div>
                            
                            <!-- <div class="accordion-item border-0 z-depth-1 hoverable mb-3 rounded-3">
                                <h2 class="accordion-header" id="flush-heading<?php echo $i; ?>">
                                    <button class="accordion-button collapsed rounded-3 fs-5" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse<?php echo $i; ?>" aria-expanded="false" aria-controls="flush-collapse<?php echo $i; ?>">
                                        Is any of my personal information stored in the App?
                                    </button>
                                </h2>
                                <div id="flush-collapse<?php echo $i; ?>" class="accordion-collapse collapse" aria-labelledby="flush-heading<?php echo $i; ?>" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body">Placeholder content for this accordion, which is intended to demonstrate the <code>.accordion-flush</code> class. This is the first item's accordion body.</div>
                                </div>
                            </div> -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="lightBlue py-5 brand-gallery">
            <div class="container-fluid container-sm">
                <div class="row g-3 mb-4">
                    <div class="col-lg-12 mx-auto mb-4">
                        <div class="fs-5 text-uppercase text-primary text-center">
                            Some stands built
                        </div>
                        <div class="fs-3 fw-bold text-center">
                            We have helped 2,760,904 companies around the world to find a stand builder
                        </div>
                        <div class="lead text-center">
                            <b>We can adapt to your budget</b> to present the best quotes in the market. They have work with us:
                        </div>
                    </div>
                </div>

                <div class="row justify-content-center g-1">
                    <?php for ($i = 1; $i <= 12; $i++) { ?>
                        <div class="col-4 col-sm-3 col-md-2">
                            <div class="card border-0 rounded-0 card-body h-100 d-flex justify-content-center align-items-center">
                                <img src="<?php echo e(asset('frontend/images/brands/brand-1.svg')); ?>" class="img-fluid brand-logo" alt="">
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </section>

        <section class="client-reviews py-5" style="background-image: url(frontend/images/bg-2.jpg);">
            <div class="container-fluid container-sm">
                <div class="row g-3 g-lg-5">
                    <div class="col-12">
                        <div class="fs-3 fw-bold text-white mb-2 text-center">CLIENT REVIEWS</div>
                        <div class="text-white mb-4 text-center">See what our clients are saying about us. We strive to make each project a success by working closely with our clients.</div>
                    </div>

                    <div class="col-lg-4">
                        <div class="card h-100 z-depth-1">
                            <div class="card-body text-white">
                                <div class="text-primary fw-bold mb-0 text-uppercase">Export Manager</div>
                                <ul class="list-inline mb-3">
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                </ul>

                                <figure class="border-warning border-start border-3 ps-3">
                                    <blockquote class="blockquote">
                                        <p>A very professional team! I'd love to work with them again. They answer swiftly and do a great job!</p>
                                    </blockquote>
                                    <figcaption class="blockquote-footer text-white">
                                        <cite title="Source Title">Daniela</cite>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="card h-100 z-depth-1">
                            <div class="card-body text-white">
                                <div class="text-primary fw-bold mb-0 text-uppercase">Corporate Communications</div>
                                <ul class="list-inline mb-3">
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                </ul>

                                <figure class="border-warning border-start border-3 ps-3">
                                    <blockquote class="blockquote">
                                        <p> They helped me find services in two different European cities, the service was satisfactory. </p>
                                    </blockquote>
                                    <figcaption class="blockquote-footer text-white">
                                        <cite title="Source Title">Felix</cite>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="card h-100 z-depth-1">
                            <div class="card-body text-white">
                                <div class="text-primary fw-bold mb-0 text-uppercase">
                                    Marketing Coordinator</div>
                                <ul class="list-inline mb-3">
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                    <li class="list-inline-item text-warning small">
                                        <i class="bi bi-star-fill"></i>
                                    </li>
                                </ul>

                                <figure class="border-warning border-start border-3 ps-3">
                                    <blockquote class="blockquote">
                                        <p> It was the first time we exhibited outside Europe, at CES. Xpostands team made it very easy for me. I recommend them to anyone exhibiting in a new country.</p>
                                    </blockquote>
                                    <figcaption class="blockquote-footer text-white">
                                        <cite title="Source Title">Katrin</cite>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="bg-white py-5 brand-gallery border-bottom">
            <div class="container-fluid container-sm">
                <div class="row g-3">
                    <div class="col-xl-3 d-flex justify-content-center justify-content-xl-start align-items-center">
                        <div class="fs-3 fw-bold text-center">
                            Official Sponsor:
                        </div>
                    </div>
                    <div class="col-xl-9">
                        <div class="row justify-content-center g-1">
                            <?php for ($i = 7; $i <= 12; $i++) { ?>
                                <div class="col-6 col-sm-3 col-lg-4 col-xl-2">
                                    <div class="card border-0 rounded-0 card-body h-100 d-flex justify-content-center align-items-center">
                                        <img src="<?php echo e(asset('frontend/images/brands/brand-1.svg')); ?>" class="img-fluid brand-logo" alt="">
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="bg-white py-5 brand-gallery border-bottom">
            <div class="container-fluid container-sm">
                <div class="row g-3">
                    <div class="col-xl-3 d-flex justify-content-center justify-content-xl-start align-items-center">
                        <div class="fs-3 fw-bold text-center">
                            As featured in:
                        </div>
                    </div>
                    <div class="col-xl-9">
                        <div class="row justify-content-center g-1">
                            <?php for ($i = 1; $i <= 6; $i++) { ?>
                                <div class="col-6 col-sm-3 col-lg-4 col-xl-2">
                                    <div class="card border-0 rounded-0 card-body h-100 d-flex justify-content-center align-items-center">
                                        <img src="<?php echo e(asset('frontend/images/brands/brand-1.svg')); ?>" class="img-fluid brand-logo" alt="">
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="bg-white py-5">
            <div class="container-fluid container-sm">
                <div class="row g-3">
                    <div class="col-sm-8">
                        <div class="fw-bold text-primary fs-4">Ask for 5 Free Quotations for your Exhibition Stands or Contact Us for more information:</div>
                        <div class="display-4">+31 20 8080653</div>
                    </div>
                    <div class="col-sm-4">
                        <img src="<?php echo e(asset('frontend/images/headphone.png')); ?>" class="img-fluid" alt="">
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- BEGIN: FOOTER PANEL -->
    <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: FOOTER PANEL -->

    <?php echo $__env->make('frontend.includes.commonJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
    <!-- Initialize Swiper -->
    <script>
        var swiper = new Swiper(".article-slider", {
            slidesPerView: 1,
            spaceBetween: 0,
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            pagination: {
                el: ".swiper-pagination",
                dynamicBullets: true,
            },
            breakpoints: {
                640: {
                    slidesPerView: 1,
                },
                768: {
                    slidesPerView: 2,
                },
                1024: {
                    slidesPerView: 2,
                },
                1200: {
                    slidesPerView: 3,
                },
            },
        });
    </script>
    <script>
        $('#hamburger').click(function() {
            $(this).toggleClass("active");
        });
    </script>
    <script>
        $(function() {
            $(window).scroll(function() {
                var aTop = $('.sh-menu').height();
                if ($(this).scrollTop() >= aTop) {
                    $(".logo-item").addClass("logo-animation")
                    $(".desktop-menu").addClass("fixed-top")
                    // instead of alert you can use to show your ad
                    // something like $('#footAd').slideup();
                } else {
                    $(".desktop-menu").removeClass("fixed-top")
                    $(".logo-item").removeClass("logo-animation")
                }
            });
        });
    </script>
</body>

</html><?php /**PATH D:\projects\project\resources\views/frontend/home.blade.php ENDPATH**/ ?>