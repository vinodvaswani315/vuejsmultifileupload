<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\cr;
// use Illuminate\Http\Request;
use App\Models\User;
use App\Models\UserRole;

use App\Models\Admin\Course;
use App\Models\Admin\CourseSemYear;
use App\Models\Admin\CourseBranch;
use App\Models\Admin\University;

use App\Models\Admin\StudentAcademicDetail;
use App\Models\Admin\StudentDetail;
use App\Models\Admin\StudentAdmissionDetail;

use App\Models\Admin\FeeGroup;
use App\Models\Admin\FeesType;
use App\Models\Admin\FeesTransaction;
use App\Models\Admin\FeeGroupDetail;
use App\Models\Admin\Session as dbSession;

use DB;
use Session;
use Validator;
use Hash;
use Cookie;

class RegistrationController extends Controller{

    public function status_count(){
        
        if(getSessionData()->session_id=="0"){

            $count['total']= StudentAdmissionDetail::where(['university_id'=>getGlobalData()->university_id])->count();
            $count['pending']= StudentAdmissionDetail::where(['status'=>null,'university_id'=>getGlobalData()->university_id])->count();
            $count['pendency']= StudentAdmissionDetail::where(['pending_status'=>'1','university_id'=>getGlobalData()->university_id])->count();
            $count['processed']= StudentAdmissionDetail::where(['status'=>'processed','university_id'=>getGlobalData()->university_id])->count();
            $count['enrolled']= StudentAdmissionDetail::where(['status'=>'enrolled','university_id'=>getGlobalData()->university_id])->count();
            $count['done']= StudentAdmissionDetail::where(['pending_status'=>'1','university_id'=>getGlobalData()->university_id])->whereNull('pending_documents')->count();
            $count['std_pendency']= StudentAdmissionDetail::where(['pending_status'=>'1','university_id'=>getGlobalData()->university_id])->whereNotNull('pending_documents')->count();

        }else{
            $count['total']= StudentAdmissionDetail::where(['university_id'=>getGlobalData()->university_id,'academic_session_year' => getSessionData()->session_id])->count();
            $count['pending']= StudentAdmissionDetail::where(['university_id'=>getGlobalData()->university_id,'academic_session_year'=> getSessionData()->session_id,'status'=>null])->count();
            $count['pendency']= StudentAdmissionDetail::where(['university_id'=>getGlobalData()->university_id,'academic_session_year'=> getSessionData()->session_id,'pending_status'=>'1'])->count();
            $count['processed']= StudentAdmissionDetail::where(['university_id'=>getGlobalData()->university_id,'academic_session_year'=> getSessionData()->session_id,'status'=>'processed'])->count();
            $count['enrolled']= StudentAdmissionDetail::where(['university_id'=>getGlobalData()->university_id,'academic_session_year'=> getSessionData()->session_id,'status'=>'enrolled'])->count();
            $count['done']= StudentAdmissionDetail::where(['pending_status'=>'1','university_id'=>getGlobalData()->university_id])->whereNull('pending_documents')->count();
            $count['std_pendency']= StudentAdmissionDetail::where(['pending_status'=>'1','university_id'=>getGlobalData()->university_id])->whereNotNull('pending_documents')->count();
         }
        return $count;
    }
    public function get_session_data(){
        // dd(getSessionData()->session_id);
        $data = dbSession::where(['university_id'=>getGlobalData()->university_id,'status'=>'active'])->get();
        // dd($data);
        $session = '';
        if($data !=null){
                
            if (getSessionData()->session_id == 0){

                $cheked = '<i class="fas fa-check"></i>';

            }else{
            }
            $cheked = '';
            $session .= '<a onclick="change_session_status(0)"
                class="btn btn-light session_button mx-1">All Session
                '.$cheked.'
            </a>';
            foreach($data as $item){
                if(getSessionData()->session_id == $item->id){
                    $selected = '<i class="fas fa-check"></i>';
                }else{
                    $selected ='';
                    }
                $session .= '<a onclick="change_session_status('.$item->id.')"
                    class="btn btn-light session_button mx-1">'.$item->session_name.'
                    '.$selected.'
                </a>';
            }
            // echo $session;
        }else{
            foreach($data as $item){
                if(getSessionData()->session_id == $item->id){
                    $selected = '<i class="fas fa-check"></i>';
                }else{
                    $selected ='';
                }
                $session .= '<a onclick="change_session_status('.$item->id.')"
                    class="btn btn-light session_button mx-1">'.$item->session_name.'
                    '.$selected.'
                </a>';
            }
        }
        echo $session;
    }
    public function index($status=null){
        if(getSessionData()->session_id=="0"){
           
            $where = [
                        ['ad_d.academic_session_year','!=',0],
                        ['ad_d.university_id',getGlobalData()->university_id]
                    ];
        }else{
            $where = [ 
                        [
                            'ad_d.academic_session_year','=',getSessionData()->session_id

                        ],
                        [

                            'ad_d.university_id','=',getGlobalData()->university_id
                        ]
                    ];
        }
        if($status == "null" || $status == 'total'){
            $registraions = User::join('student_admission_details as ad_d','ad_d.student_id','users.id')
            ->join('student_details','student_details.student_id','users.id')
            ->join('courses','courses.id','ad_d.course_name')
            ->join('semyears','semyears.id','ad_d.sem_year')
            ->join('sessions','sessions.id','ad_d.academic_session_year')
            ->join('users as created_by','created_by.id','ad_d.created_by')
            ->join('user_roles','user_roles.user_id','users.id')
            ->select(
                'users.id',
                'ad_d.id as admission_id',
                'users.profile_image',
                'student_details.application_no',
                'student_details.enrollement_no',
                'student_details.oa_no',
                'users.name',
                'student_details.father_name',
                'sessions.session_name',
                'ad_d.admission_type',
                'ad_d.status',
                'ad_d.refer_name',
                'courses.course_name',
                'semyears.semyear_name',
                'created_by.name as create_by_name',
                )
            ->where($where)
            ->where('user_roles.role_id',3)
            ->get();
           
        }else{
            if($status == "pendency"){
                $std_status = [
                    ['ad_d.pending_status','=','1']
                ];
                
            }else if($status == "done"){
                
                $std_status = [
                    ['ad_d.pending_status','=','1'],
                    ['ad_d.pending_documents','=',null]
                ];
            }else if($status == "std_pendency"){
                
                $std_status = [
                    ['ad_d.pending_status','=','1'],
                    ['ad_d.pending_documents','!=',null]
                ];
            }else if($status == "pending"){
                $std_status = [
                    ['ad_d.status','=',null]
                ];
            }else{
                $std_status = [
                    ['ad_d.status','=',$status]
                ];
            }
            $registraions = User::with(['student_academic_detail','student_admission_detail','student_detail'])
            ->join('student_admission_details as ad_d','ad_d.student_id','users.id')
            ->join('student_details','student_details.student_id','users.id')
            ->join('courses','courses.id','ad_d.course_name')
            ->join('semyears','semyears.id','ad_d.sem_year')
            ->join('users as created_by','created_by.id','ad_d.created_by')
            ->join('sessions','sessions.id','ad_d.academic_session_year')
            ->join('user_roles','user_roles.user_id','users.id')
            ->select(
                'users.id',
                'ad_d.id as admission_id',
                'users.profile_image',
                'student_details.application_no',
                'student_details.enrollement_no',
                'student_details.oa_no',
                'users.name',
                'student_details.father_name',
                'sessions.session_name',
                'ad_d.admission_type',
                'ad_d.status',
                'ad_d.refer_name',
                'courses.course_name',
                'semyears.semyear_name',
                'created_by.name as create_by_name',
                )
            ->where($std_status)
            ->where($where)
            ->where('user_roles.role_id',3)
            ->get();
          
        }
        $output = '';
        if($registraions !=null){

            $output = '<table class="table table-striped" id="all-registrations-table" >
                    <thead>
                        <tr>
                            <th style="width: 94px;">Actions</th>
                            <th style="width: 50px;">Photo</th>
                            <th style="width: 94px;">Ref No.</th>
                            <th style="width: 94px;">OA No.</th>
                            <th style="width: 94px;">Status</th>
                            <th style="width: 94px;">App ID</th>
                            <th style="width: 94px;">Student Name</th>
                            <th style="width: 94px;">Father Name</th>
                            <th style="width: 60px;">Session</th>
                            <th style="width: 50px;">Type</th>
                            <th style="width: 94px;">Course</th>
                            <th style="width: 60px;">Year/Sem</th>
                            <th style="width: 94px;">Ref Name</th>
                            <th style="width: 112px;">Counsellor Name</th>
                        </tr>
                    </thead>
                    <tbody>';
                        foreach($registraions as $key=>$data){
                            if($data->profile_image !=  null){
                                $image = asset('storage/uploade/')."/".$data->profile_image;
                            }else{
                                $image = asset('councellor_assets/image/not-found-img.jpg');
                            }
                            if($data->status !=  null){
                                $status = ucwords($data->status);
                            }else{
                                $status = '-';
                            }
                            if($data->oa_no !=  null){
                                $oa_no = ucwords($data->oa_no);
                            }else{
                                $oa_no = '-';
                            }
                            if($status == 'Pendency'){
                                $status = '<span onClick="showPendingModal('.$data->id.')">'.$status.'</span>';
                            }
                            $key = $key+1;
                            $print_url = url("admin/new-registrations/student-form/".$data->id);
                            $std_doc = url("admin/new-registrations/student-document/".$data->id);
                            $edit = url("admin/new-registrations/edit/".$data->id);
                            $url = url("admin/new-registrations/delete/".$data->id);
                            $param = "'".$url."'";
                            $output .='
                                <tr>
                                    <td>
                                        
                                        <a href="'.$print_url.'" target="_blank"><i class="fa fa-print h5 "></i></a>
                                        <i class="fas fa-calendar h5 text-success "  onClick="changeStatus('.$data->id.')" title="Change Status"></i>
                                        <a href="'.$edit.'"><i class="far fa-edit h5"></i></a>
                                    </td>
                                    <td>
                                        <img src="'.$image.'" width="30px;" style="border: .5px solid black;">
                                    </td>
                                    <td><a href="'.$std_doc.'" target="_blank">'.$data->application_no.'</a></td>
                                    <td>'.$oa_no.'</td>
                                    <td><h6>'.$status.'</h6></td>
                                    <td>'.$data->enrollement_no.'</td>
                                    <td>'.$data->name.'</td>
                                    <td>'.$data->father_name.'</td>
                                    <td>'.$data->session_name.'</td>
                                    <td>'.$data->admission_type.'</td>
                                    <td>'.$data->course_name.'</td>
                                    <td>'.$data->semyear_name.'</td>
                                    <td>'.$data->refer_name.'</td>
                                    <td>'.$data->create_by_name.'</td>
                                </tr>
                            
                            ';
                        }
            $output .= '</tbody>
                    </table>';
        }else{
            $output = '<h3 classs="text-center text-danger my-5">No Record  Found</h3>';
        }
      
        echo $output;
      
    }

   public function add(){

    return view('Counsllor.new_registration_create');
   }
   public function getAfterChangeStatus($status,$id=0){

    $registraions = StudentAdmissionDetail::with(["std_academic_details","std_details"])->where('student_id',$id)->first();
    $data['high_sheet'] = $registraions->std_academic_details->high_sheet !=null?asset('storage/uploade/')."/".$registraions->std_academic_details->high_sheet:asset('councellor_assets/image/not-found-img.jpg');
    $data['inter_sheet'] = $registraions->std_academic_details->inter_sheet !=null?asset('storage/uploade/')."/".$registraions->std_academic_details->inter_sheet:asset('councellor_assets/image/not-found-img.jpg');
    $data['ug_sheet'] = $registraions->std_academic_details->ug_sheet != null?asset('storage/uploade/')."/".$registraions->std_academic_details->ug_sheet:asset('councellor_assets/image/not-found-img.jpg');
    $data['adhar_sheet'] = $registraions->std_academic_details->adhar_sheet !=null?asset('storage/uploade/')."/".$registraions->std_academic_details->adhar_sheet:asset('councellor_assets/image/not-found-img.jpg');
    $data['user_photo'] = $registraions->std_details->user_photo !=null?asset('storage/uploade/')."/".$registraions->std_details->user_photo:asset('councellor_assets/image/not-found-img.jpg');
    // dd();
    $pending_data_db = explode(",", $registraions->pending_documents);
    $pending_std_data_array = ["Photo", "Adhar", "High_School", "Inter", "UG"];
    if($status == 'pendency'){
        $data['status_data'] ='<div class="form-group col-md-12 mt-2">';
            foreach($pending_std_data_array as $dt){
                if (in_array($dt, $pending_data_db)){
                    $checked = 'checked';
                }else{
                    $checked = '';

                }
                $data['status_data'] .='<div class="mb-2 custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" value="'.$dt.'" '.$checked.' name="pendency[]" id="'.$dt.'">
                    <label class="custom-control-label" for="'.$dt.'">'.$dt.'</label>
                </div>';
            }
            $data['status_data'] .='<div class="form-group row">
                <label class="col-lg-12 col-form-label" for="remark">Remark</label>
                <div class="col-lg-12">
                <textarea type="text" class="form-control" name="remark" id="remark">'.$registraions->pending_remark.'</textarea>
                </div>
            </div>
        </div>
        
        ';
    }if($status == 'processed'){
        $data['status_data'] = '<div class="form-group col-md-12 my-5 mx-2">
                                    <div class="form-group row">
                                        <h4>Now you can Procceed the Student from to University</h4>
                                    </div>
                                </div>';
    }if($status == 'enrolled'){
        $data['status_data'] = ' <div class="form-group col-md-12 mt-2">
        <div class="form-group row">
            <label class="col-lg-12 col-form-label" for="remark">Remark</label>
            <div class="col-lg-12">
            <input type="text" class="form-control" value="'.$registraions->std_details->enrollement_no.'" placeholder="Enter the Student Enrolled No." name="enrolled" id="remark">
            </div>
        </div>
    </div>';
    }
    $data['remark'] = '<textarea type="text" class="form-control"  name="remark" id="remark"></textarea>';

    return $data;
    
   }
    public function getAllData(Request $request){

        $model['getBranch'] = getBranch($request->u_id);
        $model['getUniversity'] =getUniversity(); 
        $model['getSemYear'] = getSemYear($request->u_id);
        $model['getCourse'] = getCourse($request->u_id);
        return $model; 
    }

    public function student_form($id){
        $registraions['data'] = StudentAdmissionDetail::with(["user_details","std_details","std_academic_details","student","course_branch","course_data","course_sem_year","sessions","university"])->where('student_id',$id)->first();
        return view('Counsllor.student_form',$registraions);
    }
    public function student_document($id){
        $registraions = StudentAdmissionDetail::with(["std_details","std_academic_details","student","course_branch","course_data","course_sem_year","sessions","university"])->where('student_id',$id)->first();
        $data['high_sheet'] = $registraions->std_academic_details->high_sheet !=null?explode("|",$registraions->std_academic_details->high_sheet):null;
        $data['inter_sheet'] = $registraions->std_academic_details->inter_sheet !=null?explode("|",$registraions->std_academic_details->inter_sheet):null;
        $data['ug_sheet'] = $registraions->std_academic_details->ug_sheet != null?explode("|",$registraions->std_academic_details->ug_sheet):null;
        $data['adhar_sheet'] = $registraions->std_academic_details->adhar_sheet !=null?explode("|",$registraions->std_academic_details->adhar_sheet):null;
        $data['user_photo'] = $registraions->std_details->user_photo;
        // dd($data);
        return view('Counsllor.student_document',$data);
        $high_sheet
    }

    /**
     * paramas array $reqest
     * Insert the student registration by the admin
     * return json String
     */
    public function store(Request $request){

        $validate =[
            "university_id" => 'required',
            "academic_session_year" => 'required',
            "admission_type" => 'required',
            "course_name" => 'required',
            "branch_name" => 'required',
            "sem_year" => 'required',
            "employment_status" => 'required',
            "first_name" => 'required',
            "last_name" => 'required',
            "father_name" => 'required',
            "mother_name" => 'required',
            "gender" => 'required',
            "birthday" => 'required',
            "current_address" => 'required',
            "city" => 'required',
            // "district" => 'required',
            // "state" => 'required',
            "email" => 'required',
            "contact_number" => 'required',
            "nationality" => 'required',
            "category_name" => 'required',
            "adhar_number" => 'required',
            "HighYear" => 'required',
            "HighSubject" => 'required',
            "HighBoard" => 'required',
            "HighStatus" => 'required',
            "InterYear" => 'required',
            "InterSubject" => 'required',
            "InterBoard" => 'required',
            "InterStatus" => 'required',
            "HighSheet.*" => 'required|image|mimes:jpg,jpeg,png|max:2048',
            "InterSheet.*.*" => 'required|image|mimes:jpg,jpeg,png|max:2048',
            "user_photo" => 'required|image|mimes:jpg,jpeg,png|max:2048',
            "adhar_sheet.*" => 'required|image|mimes:jpg,jpeg,png|max:2048',
        ];

        $validator = Validator::make($request->all(), $validate);
        if($validator->fails())
        {
            return response()->json([
                'status'=>419,
                'errors'=>$validator->messages(),
            ]);
        }
        else{
           
            $student = new User;
            $student->name = $request->first_name." ".$request->last_name;
            
            $student->std_id_card = '1';
            $student->login_enable = '1';
            $student->online_admission = '1';
            $student->approve = '1';
            
            if($request->hasFile('user_photo'))
            {
                $file = $request->file('user_photo');
                $extension = $file->getClientOriginalExtension();
                $profile_image = $file->getClientOriginalName();

                $file->storeAS('/public/uploade',$profile_image);
                
            }else{
                $profile_image = null;
            }
            
            $student->profile_image =$profile_image;
            $student->email = $request->email;
            
            $student->password =Hash::make(date('dmY',strtotime($request->birthday)));
        
            if($student->save()){

                $user_role = new UserRole;
                $user_role->user_id = $student->id;
                $user_role->role_id = 3;
                $user_role->save();

                $StudentAdmissionDetail = new  StudentAdmissionDetail;
                $StudentAdmissionDetail->university_id = $request->university_id;
                $StudentAdmissionDetail->student_id = $student->id;
                $StudentAdmissionDetail->academic_session_year=$request->academic_session_year;
                $StudentAdmissionDetail->admission_type=$request->admission_type;
                $StudentAdmissionDetail->course_name = $request->course_name;
                $StudentAdmissionDetail->branch_name = $request->branch_name;
                $StudentAdmissionDetail->sem_year = $request->sem_year;
                $StudentAdmissionDetail->refer_name = $request->refer_name;
                $StudentAdmissionDetail->created_by = auth()->user()->id;
                $StudentAdmissionDetail->status = 'pending';
                $StudentAdmissionDetail->save();

            
                $registration_no = strtoupper(substr(getGlobalData()->universtiy_name, 0, 3)).'-00'.date('Y').$student->id;
                $application_no = strtoupper(substr(getGlobalData()->universtiy_name, 0, 3)).(int) round(microtime(true) * 10);
                $model = new StudentDetail;
                $model->student_id = $student->id;
                $model->university_id = $request->university_id;
                $model->category_name = $request->category_name;
                $model->register_no = $registration_no;
                $model->application_no = $application_no;
                $model->employee_status = $request->employment_status;
                $model->first_name = $request->first_name;
                $model->last_name = $request->last_name;
                $model->gender = $request->gender;
                $model->birthday = date('Y-m-d',strtotime($request->birthday));
                $model->contact_number = $request->contact_number;
                $model->city = $request->city;
                $model->state = $request->state;
                $model->nationality = $request->nationality;
                $model->adhar_number = $request->adhar_number;
                $model->current_address = $request->current_address;
                $model->user_photo =$profile_image;
                $model->father_name = $request->father_name;
                $model->mother_name = $request->mother_name;
                $model->save();

                $StudentAcademicDetail = new StudentAcademicDetail;
                $StudentAcademicDetail->student_id = $student->id;

                $StudentAcademicDetail->high_year = $request->HighYear;
                $StudentAcademicDetail->high_subject = $request->HighSubject;
                $StudentAcademicDetail->high_board = $request->HighBoard;
                $StudentAcademicDetail->high_persentage = $request->HighStatus;
                
                if($request->hasFile('HighSheet'))
                {
                    $files = $request->file('HighSheet');
                    
                    $high_sheet = [];
                    foreach($files as $file){
                        
                        $extension = $file->getClientOriginalExtension();
                        $filename = $file->getClientOriginalName();

                        $file->storeAS('/public/uploade',$filename);
                        $high_sheet[]= $filename;
                    }
                    $high = implode("|",$high_sheet);
                    $StudentAcademicDetail->high_sheet =$high;
                }

                $StudentAcademicDetail->inter_year = $request->InterYear;
                $StudentAcademicDetail->inter_subject = $request->InterSubject;
                $StudentAcademicDetail->inter_board = $request->InterBoard;
                $StudentAcademicDetail->inter_persentage = $request->InterStatus;
                if($request->hasFile('InterSheet'))
                {
                    $files = $request->file('InterSheet');
                    $InterSheet = [];
                    foreach($files as $file){
                        
                        $extension = $file->getClientOriginalExtension();
                        $filename = $file->getClientOriginalName();
                        $file->storeAS('/public/uploade',$filename);
                        $InterSheet[]= $filename;
                    }
                    $Inter = implode("|",$InterSheet);
                    $StudentAcademicDetail->inter_sheet =$Inter;
                }


                $StudentAcademicDetail->ug_year = $request->OtherYear;
                $StudentAcademicDetail->ug_subject = $request->OtherSubject;
                $StudentAcademicDetail->ug_board = $request->OtherBoard;
                $StudentAcademicDetail->ug_persentage = $request->OtherStatus;
                if($request->hasFile('OtherSheet'))
                {
                    $files = $request->file('OtherSheet');
                    $OtherSheet = [];
                    foreach($files as $file){
                        
                        $extension = $file->getClientOriginalExtension();
                        $filename = $file->getClientOriginalName();

                        $file->storeAS('/public/uploade',$filename);
                        $OtherSheet[]= $filename;
                    }
                    $Other = implode("|",$OtherSheet);
                    $StudentAcademicDetail->ug_sheet =$Other;
                }
               

                if($request->hasFile('adhar_sheet'))
                {
                    $files = $request->file('adhar_sheet');
                    $adhar_sheet = [];
                    foreach($files as $file){
                        
                        $extension = $file->getClientOriginalExtension();
                        $filename = $file->getClientOriginalName();
                        // $filename =time() .'.' .$extension;
                        $file->storeAS('/public/uploade',$filename);
                        $adhar_sheet[]= $filename;
                    }
                    $adhar = implode("|",$adhar_sheet);
                    $StudentAcademicDetail->adhar_sheet =$adhar;
                }
                $StudentAcademicDetail->save();
                
            }
            return response()->json(['status'=>true,"message" => "Student registration has been successfull"],201);
        }
    }

    public function show($id){
        $data['users'] = User::with(['student_academic_detail','student_admission_detail','student_detail'])
        ->join('student_admission_details as ad_d','ad_d.student_id','users.id')
        ->join('courses','courses.id','ad_d.course_name')
        ->join('semyears','semyears.id','ad_d.sem_year')
        ->join('user_roles','user_roles.user_id','users.id')
        ->select('users.*','semyears.semyear_name','courses.course_name')
        
        ->find($id);

        $data['fees_data'] = fees_invoice($data['users']->student_admission_detail->student_id,$data['users']->student_admission_detail->course_name,$data['users']->student_admission_detail->branch_name,$data['users']->student_admission_detail->sem_year);
        
        return view('Counsllor.student-profile',$data);
    }
    public function edit($id){
        $data['users'] = User::with(['student_academic_detail','student_admission_detail','student_detail'])
            ->join('student_admission_details as ad_d','ad_d.student_id','users.id')
            ->join('courses','courses.id','ad_d.course_name')
            ->join('semyears','semyears.id','ad_d.sem_year')
            ->join('user_roles','user_roles.user_id','users.id')
            ->select('users.*','semyears.semyear_name','courses.course_name')
            
            ->find($id);
            $data['fees_data'] = fees_invoice($data['users']->student_admission_detail->student_id,$data['users']->student_admission_detail->course_name,$data['users']->student_admission_detail->branch_name,$data['users']->student_admission_detail->sem_year);
            
            // dd($data);
        return view('Counsllor.new_registration_edit',$data);
    }

    public function update(Request $request){

        // dd($request->all());
        $validate =[
            "university_id" => 'required',
            "academic_session_year" => 'required',
            "admission_type" => 'required',
            "course_name" => 'required',
            "branch_name" => 'required',
            "sem_year" => 'required',
            "employment_status" => 'required',
            "first_name" => 'required',
            "last_name" => 'required',
            "father_name" => 'required',
            "mother_name" => 'required',
            "gender" => 'required',
            "birthday" => 'required',
            "current_address" => 'required',
            "city" => 'required',
            // "district" => 'required',
            // "state" => 'required',
            "email" => 'required',
            "contact_number" => 'required',
            "nationality" => 'required',
            "category_name" => 'required',
            "adhar_number" => 'required',
            "HighYear" => 'required',
            "HighSubject" => 'required',
            "HighBoard" => 'required',
            "HighStatus" => 'required',
            "InterYear" => 'required',
            "InterSubject" => 'required',
            "InterBoard" => 'required',
            "InterStatus" => 'required',
            // "HighSheet.*" => 'required|image|mimes:jpg,jpeg,png|max:2048',
            // "InterSheet.*.*" => 'required|image|mimes:jpg,jpeg,png|max:2048',
            // "user_photo" => 'required|image|mimes:jpg,jpeg,png|max:2048',
            // "adhar_sheet.*" => 'required|image|mimes:jpg,jpeg,png|max:2048',
        ];

        $validator = Validator::make($request->all(), $validate);
        if($validator->fails())
        {
            return response()->json([
                'status'=>419,
                'errors'=>$validator->messages(),
            ]);
        }
        else{
           
            $student = User::find($request->student_id);
            $student->name = $request->first_name." ".$request->last_name;
            
            $student->std_id_card = '1';
            $student->login_enable = '1';
            $student->online_admission = '1';
            $student->approve = '1';
            
            if($request->hasFile('user_photo'))
            {
                $file = $request->file('user_photo');
                $extension = $file->getClientOriginalExtension();
                $profile_image = $file->getClientOriginalName();

                $file->storeAS('/public/uploade',$profile_image);
                $student->profile_image =$profile_image;
                
            }
            $student->email = $request->email;
            
            $student->password =Hash::make(date('dmY',strtotime($request->birthday)));
        
            if($student->save()){

                $check_data =StudentAdmissionDetail::where('student_id',$request->student_id)->first();
                $StudentAdmissionDetail =StudentAdmissionDetail::find($check_data->id);
                $StudentAdmissionDetail->university_id = $request->university_id;
                $StudentAdmissionDetail->student_id = $student->id;
                $StudentAdmissionDetail->academic_session_year=$request->academic_session_year;
                $StudentAdmissionDetail->admission_type=$request->admission_type;
                $StudentAdmissionDetail->course_name = $request->course_name;
                $StudentAdmissionDetail->branch_name = $request->branch_name;
                $StudentAdmissionDetail->sem_year = $request->sem_year;
                $StudentAdmissionDetail->refer_name = $request->refer_name;
                $StudentAdmissionDetail->created_by = auth()->user()->id;
                $StudentAdmissionDetail->status = 'pending';
                $StudentAdmissionDetail->save();

            
                $registration_no = strtoupper(substr(getGlobalData()->universtiy_name, 0, 3)).'-00'.date('Y').$student->id;
                $application_no = strtoupper(substr(getGlobalData()->universtiy_name, 0, 3)).(int) round(microtime(true) * 10);
                
                $check_data_details =StudentDetail::where('student_id',$request->student_id)->first();
                $model =StudentDetail::find($check_data_details->id);
                $model->student_id = $student->id;
                $model->university_id = $request->university_id;
                $model->category_name = $request->category_name;
                $model->register_no = $registration_no;
                $model->application_no = $application_no;
                $model->employee_status = $request->employment_status;
                $model->first_name = $request->first_name;
                $model->last_name = $request->last_name;
                $model->gender = $request->gender;
                $model->birthday = date('Y-m-d',strtotime($request->birthday));
                $model->contact_number = $request->contact_number;
                $model->city = $request->city;
                $model->state = $request->state;
                $model->nationality = $request->nationality;
                $model->adhar_number = $request->adhar_number;
                $model->current_address = $request->current_address;
                if($request->hasFile('user_photo'))
                {
                    $file = $request->file('user_photo');
                    $extension = $file->getClientOriginalExtension();
                    $profile_image = $file->getClientOriginalName();

                    $file->storeAS('/public/uploade',$profile_image);
                    $model->user_photo =$profile_image;
                    
                }
                $model->father_name = $request->father_name;
                $model->mother_name = $request->mother_name;
                $model->save();

                $check_data_academic =StudentAcademicDetail::where('student_id',$request->student_id)->first();
                $StudentAcademicDetail =StudentAcademicDetail::find($check_data_academic->id);
                $StudentAcademicDetail->student_id = $student->id;
                $StudentAcademicDetail->high_year = $request->HighYear;
                $StudentAcademicDetail->high_subject = $request->HighSubject;
                $StudentAcademicDetail->high_board = $request->HighBoard;
                $StudentAcademicDetail->high_persentage = $request->HighStatus;
                
                if($request->hasFile('HighSheet'))
                {
                    $files = $request->file('HighSheet');
                    
                    $high_sheet = [];
                    foreach($files as $file){
                        
                        $extension = $file->getClientOriginalExtension();
                        $filename = $file->getClientOriginalName();

                        $file->storeAS('/public/uploade',$filename);
                        $high_sheet[]= $filename;
                    }
                    $high = implode("|",$high_sheet);
                    $StudentAcademicDetail->high_sheet =$high;
                }

                $StudentAcademicDetail->inter_year = $request->InterYear;
                $StudentAcademicDetail->inter_subject = $request->InterSubject;
                $StudentAcademicDetail->inter_board = $request->InterBoard;
                $StudentAcademicDetail->inter_persentage = $request->InterStatus;
                if($request->hasFile('InterSheet'))
                {
                    $files = $request->file('InterSheet');
                    $InterSheet = [];
                    foreach($files as $file){
                        
                        $extension = $file->getClientOriginalExtension();
                        $filename = $file->getClientOriginalName();
                        $file->storeAS('/public/uploade',$filename);
                        $InterSheet[]= $filename;
                    }
                    $Inter = implode("|",$InterSheet);
                    $StudentAcademicDetail->inter_sheet =$Inter;
                }


                $StudentAcademicDetail->ug_year = $request->UGYear;
                $StudentAcademicDetail->ug_subject = $request->UGSubject;
                $StudentAcademicDetail->ug_board = $request->UGBoard;
                $StudentAcademicDetail->ug_persentage = $request->UGStatus;
                if($request->hasFile('GraduationSheet'))
                {
                    $files = $request->file('GraduationSheet');
                    $OtherSheet = [];
                    foreach($files as $file){
                        
                        $extension = $file->getClientOriginalExtension();
                        $filename = $file->getClientOriginalName();

                        $file->storeAS('/public/uploade',$filename);
                        $OtherSheet[]= $filename;
                    }
                    $Other = implode("|",$OtherSheet);
                    $StudentAcademicDetail->ug_sheet =$Other;
                }
               

                if($request->hasFile('adhar_sheet'))
                {
                    $files = $request->file('adhar_sheet');
                    $adhar_sheet = [];
                    foreach($files as $file){
                        
                        $extension = $file->getClientOriginalExtension();
                        $filename = $file->getClientOriginalName();
                        // $filename =time() .'.' .$extension;
                        $file->storeAS('/public/uploade',$filename);
                        $adhar_sheet[]= $filename;
                    }
                    $adhar = implode("|",$adhar_sheet);
                    $StudentAcademicDetail->adhar_sheet =$adhar;
                }
                $StudentAcademicDetail->save();
                
            }
            return response()->json(['status'=>true,"message" => "Student registration has been successfull"],201);
        }
    }
    public function std_update_documents(Request $request){

        // dd($request->all());
        $validate =[
            // "HighYear" => 'required',
            // "HighSubject" => 'required',
            // "HighBoard" => 'required',
            // "HighStatus" => 'required',
            // "InterYear" => 'required',
            // "InterSubject" => 'required',
            // "InterBoard" => 'required',
            // "InterStatus" => 'required',
            // "UGYear" => 'required',
            // "UGSubject" => 'required',
            // "UGBoard" => 'required',
            // "UGStatus" => 'required',
            // "HighSheet" => 'required|image|mimes:jpg,jpeg,png|max:2048',
            // "InterSheet" => 'required|image|mimes:jpg,jpeg,png|max:2048',
            // "user_photo" => 'required|image|mimes:jpg,jpeg,png|max:2048',
            // "adhar_sheet" => 'required|image|mimes:jpg,jpeg,png|max:2048',
            // "GraduationSheet" => 'required|image|mimes:jpg,jpeg,png|max:2048',
        ];

        $validator = Validator::make($request->all(), $validate);
        if($validator->fails())
        {
            return response()->json([
                'status'=>419,
                'errors'=>$validator->messages(),
            ]);
        }
        else{
           
            $student = User::find($request->student_id);
            
            if($request->hasFile('user_photo'))
            {
                $file = $request->file('user_photo');
                $extension = $file->getClientOriginalExtension();
                $profile_image = $file->getClientOriginalName();

                $file->storeAS('/public/uploade',$profile_image);
                $student->profile_image =$profile_image;
                
            }
          
            if($student->save()){

              

            
                $check_data_details =StudentDetail::where('student_id',$request->student_id)->first();
                $model =StudentDetail::find($check_data_details->id);
               
                if($request->hasFile('user_photo'))
                {
                    $file = $request->file('user_photo');
                    $extension = $file->getClientOriginalExtension();
                    $profile_image = $file->getClientOriginalName();

                    $file->storeAS('/public/uploade',$profile_image);
                    $model->user_photo =$profile_image;
                    
                }
               
                $model->save();

                $check_data_academic =StudentAcademicDetail::where('student_id',$request->student_id)->first();
                $StudentAcademicDetail =StudentAcademicDetail::find($check_data_academic->id);
                $StudentAcademicDetail->high_year = $request->HighYear;
                $StudentAcademicDetail->high_subject = $request->HighSubject;
                $StudentAcademicDetail->high_board = $request->HighBoard;
                $StudentAcademicDetail->high_persentage = $request->HighStatus;
                
                if($request->hasFile('HighSheet'))
                {
                    $file = $request->file('HighSheet');
                    $extension = $file->getClientOriginalExtension();
                    $high = $file->getClientOriginalName();
    
                    $file->storeAS('/public/uploade',$high);
                    $StudentAcademicDetail->high_sheet =$high;

                    
                }

                $StudentAcademicDetail->inter_year = $request->InterYear;
                $StudentAcademicDetail->inter_subject = $request->InterSubject;
                $StudentAcademicDetail->inter_board = $request->InterBoard;
                $StudentAcademicDetail->inter_persentage = $request->InterStatus;
                if($request->hasFile('InterSheet'))
                {
                    $file = $request->file('InterSheet');
                    $extension = $file->getClientOriginalExtension();
                    $Inter = $file->getClientOriginalName();
    
                    $file->storeAS('/public/uploade',$Inter);
                    $StudentAcademicDetail->inter_sheet =$Inter;
                }


                $StudentAcademicDetail->ug_year = $request->UGYear;
                $StudentAcademicDetail->ug_subject = $request->UGSubject;
                $StudentAcademicDetail->ug_board = $request->UGBoard;
                $StudentAcademicDetail->ug_persentage = $request->UGStatus;
                if($request->hasFile('GraduationSheet'))
                {
                    $file = $request->file('GraduationSheet');
                    $extension = $file->getClientOriginalExtension();
                    $Other = $file->getClientOriginalName();
    
                    $file->storeAS('/public/uploade',$Other);
                    $StudentAcademicDetail->ug_sheet =$Other;

                }
               

                if($request->hasFile('adhar_sheet'))
                {
                    $files = $request->file('adhar_sheet');
                    $extension = $files->getClientOriginalExtension();
                    $adhar = $files->getClientOriginalName();
    
                    $files->storeAS('/public/uploade',$adhar);
                    $StudentAcademicDetail->adhar_sheet =$adhar;
                }
                $StudentAcademicDetail->save();
                
            }
            return response()->json(['status'=>true,"message" => "Student Document has been Uploaded"],201);
        }
    }
    public function getSemBranchData(Request $request)
    {
        
        $model['semyear'] =CourseSemYear::join('courses','course_semyears.course_id','=','courses.id')->where('courses.university_id',$request->u_id)->where('course_semyears.course_id',$request->course_id)->get();
        
        if($request->admission_type){

            if($request->admission_type == 'Credit Transfer'){
                $where = [
                    ['course_semyears.semyear_name' ,'not like','%'.'1-'.'%'],
                    
                ];
            }elseif($request->admission_type == 'Regular'){
                
                $where = [
                    ['course_semyears.semyear_name' ,'like','%'.'1-'.'%'],
                    
                ];
                
            }elseif($request->admission_type == 'Lateral'){
                $where = [
                    ['course_semyears.semyear_name' ,'like','%'.'3-'.'%'],
                   
                   ];
            }
            $model['semyear_by_admission_type'] =CourseSemYear::join('courses','course_semyears.course_id','=','courses.id')->where('courses.university_id',$request->u_id)->where('course_semyears.course_id',$request->course_id)->where($where)->get();
        }
        $model['fees_type'] =  FeesType::where(['university_id'=>$request->u_id,'course_id'=>$request->course_id,'common_fees'=>'0'])->get();
        


        $model['branch'] =CourseBranch::join('courses','course_branches.course_id','=','courses.id')->where('courses.university_id',$request->u_id)->where('course_branches.course_id',$request->course_id)->get();
        
        $model['fees_groups'] =FeeGroup::where('university_id',$request->u_id)->get();
       
         return $model;
    }
    public function change_status_under_process(Request $request){

        // dd($request->all(),implode(",", $request->pendency));
        if($request->status == 'processed'){
            
            $update_status = StudentAdmissionDetail::where('student_id',$request->student_id)->update(["status" => $request->status]);
            $update_enrolled = StudentDetail::where('student_id',$request->student_id)->update(["oa_no" => (int) round(microtime(true) * 2)]);
        
        }else if($request->status == 'pendency'){
            if(isset($request->pendency)){
                $update_status = StudentAdmissionDetail::where('student_id',$request->student_id)
                ->update(
                    [
                        "status" => $request->status,
                        "pending_documents" => implode(",", $request->pendency),
                        "pending_remark" => $request->remark,
                        "pending_status" => '1',
                    ]
                );

            }else{
                $check_status = StudentDetail::where('student_id',$request->student_id)->first();
                if($check_status->enrollement_no == null){

                    $update_status = StudentAdmissionDetail::where('student_id',$request->student_id)
                    
                    ->update(
                        [
                            "status" => 'processed',
                            "pending_documents" => null,
                            "pending_remark" => $request->remark,
                            "pending_status" => '1',
                        ]
                    );
                }else{
                    $update_status = StudentAdmissionDetail::where('student_id',$request->student_id)
                    
                    ->update(
                        [
                            "status" => 'enrolled',
                            "pending_documents" => null,
                            "pending_remark" => $request->remark,
                            "pending_status" => '1',
                        ]
                    );

                }
            }

        }else if($request->status == 'enrolled'){

            $update_status = StudentAdmissionDetail::where('student_id',$request->student_id)->update(["status" => $request->status]);
            $update_enrolled = StudentDetail::where('student_id',$request->student_id)->update(["enrollement_no" => $request->enrolled]);
        
        }
     
        return response()->json(['status'=>true,"message" => "Student Status has been changed"],201);
        
    }
    public function uplaodPendingDataFrom($id){
        $data['users'] = getStudentData($id);
        // dd($data);
        return view('Counsllor.uploadePendingDocuments',$data);
    }
    
}
