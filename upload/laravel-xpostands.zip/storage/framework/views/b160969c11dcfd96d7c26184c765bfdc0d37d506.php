<!doctype html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <?php echo $__env->make('frontend.includes.commoncss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/stand-request.min.css')); ?>">
    <title>Contractor Signup</title>
</head>

<body class="d-flex flex-column h-100 bg-light">
<router-view></router-view>
    <!-- BEGIN: HEADER PANEL -->
    <?php echo $__env->make('frontend.includes.secondryheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: HEADER PANEL -->

    <main class="add-secondary-header" id="stand-request-panel">
        <!-- ==================================== -->
        <!-- Progress Bar & Badges -->
        <!-- ==================================== -->

        <!-- Progress Bar -->
        <div>
            <div class="progress bg-light" style="height: 3px;">
                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-label="Example 1px high" :style="{width: 12.5%}" :aria-valuenow="progress_count" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
        </div>
        <!-- Badges -->
        <section class="alert rounded-0 border-0 alert-primary py-3">
            <div class="container-fluid container-md">
                <div class="row">
                    <div class="col-12">
                        <div class="d-flex flex-column flex-md-row align-items-md-center">
                            <div class="p-1 me-2 text-muted text-nowrap">Your selection:</div>
                            <div class="d-flex align-items-center flex-wrap">
                                <div class="p-1">
                                    <h5 class="mb-0">
                                        <span class="badge bg-info fw-normal rounded-5 px-3">
                                            <i class="bi bi-layers"></i> Design + Assembly
                                        </span>
                                    </h5>
                                </div>
                                <div class="p-1">
                                    <h5 class="mb-0">
                                        <span class="badge bg-info fw-normal rounded-5 px-3">
                                            <i class="bi bi-geo-alt"></i> Las Vegas
                                        </span>
                                    </h5>
                                </div>
                                <div class="p-1">
                                    <h5 class="mb-0">
                                        <span class="badge bg-info fw-normal rounded-5 px-3">
                                            <i class="bi bi-arrows-move"></i> 52 m<sup>2</sup>
                                        </span>
                                    </h5>
                                </div>
                                <div class="p-1">
                                    <h5 class="mb-0">
                                        <span class="badge bg-info fw-normal rounded-5 px-3">
                                            <i class="bi bi-calendar"></i> Power Uzbekistan
                                        </span>
                                    </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ==================================== -->
        <!-- Main Area -->
        <!-- ==================================== -->
        <section class="pt-3 pb-4" id="enquiry-panel">
            <div class="container-fluid container-md">
                <div class="row g-3">
                    <!-- ****************************************** -->
                    <!-- Personal Information Panel -->
                    <!-- ****************************************** -->
                    <div :class="{'d-block': step==1, 'd-none': step!=1}" class="col-sm-9 col-lg-7 col-xl-5 mx-auto">
                        <!-- Panel Title -->
                        <div class="fs-5 fw-bold text-uppercase d-flex flex-column mb-4">
                            <div>PERSONAL INFORMATION</div>
                            <div class="border-bottom border-primary border-3 mt-2" style="width: 50px;"></div>
                        </div>

                        <div class="d-flex align-items-center mb-3">
                            <img src="<?php echo e(asset('frontend/images/user-avatar.svg')); ?>" class="img-fluid stand-avatar rounded-circle me-3" alt="">
                            <h5 class="text-text-capitalize mb-0"><?php echo e($data->contact_person_name); ?></h5>
                        </div>

                        <div class="card border-0 rounded-5">
                            <div class="card-body">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <h6 class="fw-bold">Country:</h6>
                                        <p class="mb-0 text-muted">United States</p>
                                    </li>
                                    <!-- <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <h6 class="fw-bold">Counter Code:</h6>
                                        <p class="mb-0 text-muted">+1</p>
                                    </li> -->
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <h6 class="fw-bold">Contact No:</h6>
                                        <p class="mb-0 text-muted">
                                            <a href="tel:9999933333"><?php echo e($data->contact_number); ?></a>
                                        </p>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <h6 class="fw-bold">Email:</h6>
                                        <p class="mb-0 text-muted">
                                            <a href="mailto:rajesh@gmail.com"><?php echo e($data->email); ?></a>
                                        </p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- ****************************************** -->
                    <!-- Organizational Information Panel -->
                    <!-- ****************************************** -->
                    <div :class="{'d-block': step==2, 'd-none': step!=2}" class="col-sm-9 col-lg-7 col-xl-5 mx-auto">
                        <!-- Panel Title -->
                        <div class="fs-5 fw-bold text-uppercase d-flex flex-column mb-4">
                            <div>Organizational Information</div>
                            <div class="border-bottom border-primary border-3 mt-2" style="width: 50px;"></div>
                        </div>

                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" ref="company" v-model="formData.company" id="company" placeholder="Company Name">
                            <div class="invalid-feedback">
                            </div>
                            <label for="company">Company Name</label>
                        </div>
                        <div class="form-floating">
                            <input type="text" class="form-control" ref="website" v-model="formData.website" id="website" placeholder="Company Website">
                            <div class="invalid-feedback">
                            </div>
                            <label for="website">Company Website</label>
                        </div>
                    </div>

                    <!-- ****************************************** -->
                    <!-- Stand Detail Panel -->
                    <!-- ****************************************** -->
                    <div :class="{'d-block': step==3, 'd-none': step!=3}" class="col-lg-8 mx-auto">
                        <!-- Panel Title -->
                        <div class="fs-5 fw-bold text-uppercase d-flex flex-column mb-4">
                            <div>STAND DETAILS</div>
                            <div class="border-bottom border-primary border-3 mt-2" style="width: 50px;"></div>
                        </div>
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="lead">Select the event country and city where you need the stand <span class="text-danger">*</span> :</div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-floating mb-0">
                                    <input type="text" class="form-control" ref="event_country" v-model="formData.event_country" id="event_country" placeholder="Event Country">
                                    <div class="invalid-feedback">
                                    </div>
                                    <label for="">Event Country<span class="text-danger">*</span></label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-floating mb-0">
                                    <input type="text" class="form-control" ref="event_city" v-model="formData.event_city" id="event_city" placeholder="Event City">
                                    <div class="invalid-feedback">
                                    </div>
                                    <label for="">Event City<span class="text-danger">*</span></label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="mb-1 fw-bold">In which trade show do you exhibit?<span class="text-danger">*</span></div>
                                <div class="form-floating mb-0">
                                    <input type="text" class="form-control" ref="event_name" v-model="formData.event_name" id="event_name" placeholder="Trade Show Name">
                                    <div class="invalid-feedback">
                                    </div>
                                    <label for="">Trade Show Name</label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="mb-1 fw-bold">What’s your stand requirements?<span class="text-danger">*</span></div>
                                <div class="row g-3">
                                    <div class="col-6">
                                        <div class="form-floating mb-0">
                                            <input type="number" class="form-control" ref="stand_size" v-model="formData.stand_size" id="stand_size" placeholder="Size">
                                            <div class="invalid-feedback">
                                            </div>
                                            <label for="">Size</label>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-floating">
                                            <select class="form-select" ref="stand_size_unit" v-model="formData.stand_size_unit" id="stand_size_unit" aria-label="Floating label select example">
                                                <option value="square-meters">Square Meters</option>
                                                <option value="square feet">Square Feet</option>
                                            </select>
                                            <div class="invalid-feedback">
                                            </div>
                                            <label for="floatingSelect">Select menu</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="mb-1 fw-bold">Services you need<span class="text-danger">*</span></div>

                                <div class="form-check">
                                    <input class="form-check-input" type="radio" v-model="formData.service_need" id="service_1"  value="need-stand" checked>
                                    <label class="form-check-label" for="service_1">
                                        I need the stand design, construction and assembly
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" v-model="formData.service_need" id="service_2" value="already-have-stand">
                                    <label class="form-check-label" for="service_2" >
                                        I already have a stand design, I just need the construction and assembly
                                    </label>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="mb-1 fw-bold">Have you already booked the space in the tradeshow?</div>

                                <div class="form-check">
                                    <input class="form-check-input" type="radio" v-model="formData.own_space" id="space_book_yes"  value="yes" checked>
                                    <label class="form-check-label" for="space_book_yes">
                                        Yes, I already booked the space and location
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" v-model="formData.own_space" id="space_book_no"  value="no" id="space_book_no">
                                    <label class="form-check-label">
                                        No, I´m still evaluating and I need to know the stand price
                                    </label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="mb-2 fw-bold">In which currency would you like to receive the quotes?</div>
                                <div class="form-floating">
                                    <select class="form-select" id="estimate_currency" v-model="formData.estimate_currency" aria-label="Floating label select example">
                                        <option selected value="dollar">$ = Dollar</option>
                                        <option value="euro">€ = Euro</option>
                                    </select>
                                    <label for="estimate_currency">Select menu</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ****************************************** -->
                    <!-- Pricing Information Panel -->
                    <!-- ****************************************** -->
                    <div :class="{'d-block': step==4, 'd-none': step!=4}" class="col-lg-6 mx-auto">
                        <!-- Panel Title -->
                        <div class="fs-5 fw-bold text-uppercase d-flex flex-column mb-4">
                            <div>PRICING Information</div>
                            <div class="border-bottom border-primary border-3 mt-2" style="width: 50px;"></div>
                        </div>
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="lead">To select the right materials for the design and construction of your stand please let us know which price range works best for you.</div>
                            </div>

                            <div class="col-12">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" v-model="formData.price" id="range_1" value="Less than $70200">
                                    <label class="form-check-label" for="range_1">
                                        Less than $70200
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" v-model="formData.price" id="range_2" value="Between $70200 and $93600">
                                    <label class="form-check-label" for="range_2">
                                        Between $70200 and $93600
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" v-model="formData.price" id="range_3" value="Between $93600 and $117000">
                                    <label class="form-check-label" for="range_3">
                                        Between $93600 and $117000
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" v-model="formData.price" id="range_4" value="More than $117000">
                                    <label class="form-check-label" for="range_4">
                                        More than $117000
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ****************************************** -->
                    <!-- Stand Element Panel -->
                    <!-- ****************************************** -->
                    <div :class="{'d-block': step==5, 'd-none': step!=5}" class="col-lg-9 mx-auto">
                        <!-- Panel Title -->
                        <div class="fs-5 fw-bold text-uppercase d-flex flex-column mb-4">
                            <div>Stand Element</div>
                            <div class="border-bottom border-primary border-3 mt-2" style="width: 50px;"></div>
                        </div>
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="lead">What elements do you need in the stand?</div>
                            </div>

                            <div class="col-sm-6 col-xl-4" v-for="(element,index) in standElements">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="form-check mb-0">
                                            <input class="form-check-input" style="margin-top: 8px;" v-model="formData.stand_elements" type="checkbox" :value="element.id" :id="'element_'+index">
                                            <label class="form-check-label d-flex align-items-center stretched-link cursor-pointer" :for="'element_'+index">
                                            <img :src="'<?php echo e(asset('frontend/images')); ?>/'+element.icon" class="img-fluid element-img" alt="">
                                                <div class="ps-2">{{element.item_name}}</div>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ****************************************** -->
                    <!-- Give us more details Panel -->
                    <!-- ****************************************** -->
                    <div :class="{'d-block': step==6, 'd-none': step!=6}" class="col-lg-8 mx-auto">
                        <!-- Panel Title -->
                        <div class="fs-5 fw-bold text-uppercase d-flex flex-column mb-4">
                            <div>Give us more details</div>
                            <div class="border-bottom border-primary border-3 mt-2" style="width: 50px;"></div>
                        </div>
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="lead">Specify any additional information like any <b>deadlines for quote submission</b> or if you stand needs a <b>specific brand identity, construction material, and construction type</b>. This information is helpful for designing the stand.</div>
                            </div>

                            <div class="col-12">
                                <textarea class="form-control" v-model="formData.event_details" id="exampleFormControlTextarea1" rows="3"></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- ****************************************** -->
                    <!-- upload Panel -->
                    <!-- ****************************************** -->
                    <div :class="{'d-block': step==7, 'd-none': step!=7}" class="col-lg-9 mx-auto">
                        <!-- Panel Title -->
                        <div class="fs-5 fw-bold text-uppercase d-flex flex-column mb-4">
                            <div>Upload Request</div>
                            <div class="border-bottom border-primary border-3 mt-2" style="width: 50px;"></div>
                        </div>
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="lead">Do you want to attach some design, idea or concept of how your stand should be? This would help us to understand better what do you have in mind.</div>
                            </div>
                            <div class="col-12 d-flex justify-content-end">
                                <button class="btn btn-primary text-white px-4">Add More File</button>
                            </div>

                            <div class="col-sm-6">
                                <div class="card z-depth-1 hoverable p-3 rounded-3 bg-white">
                                    <div class="d-flex justify-content-center align-items-center w-100">
                                        <label for="dropzone-file" class="upload-box d-flex justify-content-center align-items-center w-100 flex-column border border-2 cursor-pointer rounded-5">
                                            <div class="d-flex justify-content-center align-items-center w-100 flex-column py-4">
                                                <div class="text-center text-muted display-6 mb-3"><i class="bi bi-cloud-upload"></i></div>

                                                <div class="text-center">
                                                    <b>Drag your image here or</b> browse
                                                </div>
                                                <div class="text-center small text-muted">
                                                    Supported file: PDF, Doc, Excel, JPG, Zip, and RAR files (Max 300 MB)
                                                </div>
                                            </div>
                                            <input id="dropzone-file" @change="onFileChange($event)" type="file" class="d-none">
                                        </label>
                                    </div>
                                    <div class="alert alert-success mt-3 mb-0" role="alert">
                                        File jpg.jpg is attached successfully.
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="col-sm-6">
                                <div class="card z-depth-1 hoverable border-0 p-3 rounded-3 bg-white position-relative">
                                    <button type="button" class="btn btn-link text-danger position-absolute px-1 top-0 end-0" aria-label="Close">
                                        <i class="bi bi-x-lg"></i>
                                    </button>
                                    <div class="d-flex justify-content-center align-items-center w-100">
                                        <label for="dropzone-file" class="upload-box d-flex justify-content-center align-items-center w-100 flex-column border border-2 cursor-pointer rounded-5">
                                            <div class="d-flex justify-content-center align-items-center w-100 flex-column py-4">
                                                <div class="text-center text-muted display-6 mb-3"><i class="bi bi-cloud-upload"></i></div>

                                                <div class="text-center">
                                                    <b>Drag your image here or</b> browse
                                                </div>
                                                <div class="text-center small text-muted">
                                                    Supported file: PDF, Doc, Excel, JPG, Zip, and RAR files (Max 300 MB)
                                                </div>
                                            </div>
                                            <input id="dropzone-file" type="file" class="d-none">
                                        </label>
                                    </div>
                                    <div class="alert alert-success mt-3 mb-0" role="alert">
                                        File jpg.jpg is attached successfully.
                                    </div>
                                </div>
                            </div> -->
                        </div>
                    </div>

                    <!-- ****************************************** -->
                    <!-- Thanks Panel -->
                    <!-- ****************************************** -->
                    <!-- <div :class="{'d-block': step==8, 'd-none': step!=8}" class="col-lg-10 mx-auto">
                        <div class="display-5 text-center fw-bold">Thank you for reaching us!</div>
                        <div class="display-5 text-center">we have received your request and our representative will get in touch with you soon.</div>
                    </div> -->

                    <!-- ****************************************** -->
                    <!-- Previous & Next Panel -->
                    <!-- ****************************************** -->
                    <div class="col-md-12 d-flex justify-content-center align-items-center mt-5">
                        <ul class="list-inline mb-0">

                                <li v-show="step>1" class="list-inline-item">
                                    <a @click.prevent="prevStep" class="btn btn-dark text-white rounded-pill px-4">
                                        <i class="bi bi-arrow-left me-1"></i> Previous
                                    </a>
                                </li>
                                
                                <li v-show="step<max_step" class="list-inline-item">
                                    <a @click.prevent="nextStep" class="btn btn-primary text-white rounded-pill px-4">
                                        Next <i class="bi bi-arrow-right ms-1"></i>
                                    </a>
                                </li>

                                <li v-show="step==max_step" class="list-inline-item">
                                    <a @click.prevent="onSubmit" class="btn btn-primary text-white rounded-pill px-4">
                                        Sunmit <i class="bi bi-arrow-right ms-1"></i>
                                    </a>
                                </li>

                        </ul>
                    </div>
                </div>
            </div>
        </section>
    </main>


    <!-- BEGIN: FOOTER PANEL -->
    <!-- <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
    <!-- END: FOOTER PANEL -->
    
    <?php echo $__env->make('frontend.includes.commonJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    <script>
    var APP_URL = <?php echo json_encode(url('/')); ?>

    axios.defaults.headers.common = {
    'X-CSRF-TOKEN' : document.querySelector('meta[name="csrf-token"]').getAttribute('content')
    };
    
    createApp({
    data() {
        return {
            max_step:7,
            progress_by:12.5,
            progress_count: 12.5,
            step: 1,
            files:[],
            formData:{
                stand_size_unit: 'square-meters',
                onlyValidate: true,
                validateAndSunmit:false,
                step: 0
            },
            continents:[],
            standElements:[],
            enquiryData:{

            }
        }
    },
    mounted(){
        this.formData = <?php echo json_encode($data, 15, 512) ?>

        if(this.formData.stand_size_unit===null)
        {
            this.formData.stand_size_unit = "square-meters"
        }

        
        this.formData.stand_elements = []
        

        this.formData.onlyValidate = true
        this.formData.validateAndSunmit = false


        this.load_standElements()
    },
    methods:{
        onFileChange(e){
            this.files.push(e.target.files[0]);
        },
        nextStep()
        {   
            this.progress_count = this.progress_by * this.step
            this.onSubmit();
            // this.step = this.step + 1;
        },
        prevStep(){
            this.progress_count = this.progress_by * this.step
            this.step = this.step - 1;
        },
        onSubmit()
        {

            $(".is-invalid").removeClass('is-invalid')

            if(this.step==this.max_step)
            {
                this.formData.onlyValidate = false
                this.formData.validateAndSunmit = true                
            }
           
            this.formData.step = this.step

            axios.post("update-enquiry", this.formData).then(function (response) {
                
                if(response.data.status=='success')
                {
                    window.location.href = APP_URL+response.data.goto
                }
                
            }).catch((errors)=>{
                
                this.loading = false;
                
                this.step = errors.response.data.goto_step
                
                $(".is-invalid").removeClass('is-invalid')
                Object.keys(errors.response.data.error).forEach((key,index)=>
                {

                    var el = this.$refs[key];
                    el.classList.remove("is-invalid");
                    el.classList.add("is-invalid");
                    el.nextElementSibling.innerText = errors.response.data.error[key][0]

                    if(index==0)
                    {
                        el.scrollIntoView({
                            behavior: "smooth",
                            block: "end",
                            inline: "nearest",
                        });
                    }
                })
                
            });
        },
        loadContinents()
        {
            axios.get("api/continents-countries").then((response)=>{

                this.continents = response.data

            }).catch(()=>{
            })
        },
        load_standElements()
        {
            axios.get("api/stand-elements").then((response)=>{

                this.standElements = response.data

            }).catch(()=>{
            })
        }
    }
    }).mount('#enquiry-panel')
</script>
</body>

</html><?php /**PATH E:\laravel-xpostands\resources\views/frontend/send-enquiry.blade.php ENDPATH**/ ?>