
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo $__env->make('contractor.includes.commoncss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('contractor/assets/css/home.min.css')); ?>">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
    <title>Home</title>
</head>

<body class="overflow-hidden">
    <!-- BEGIN: HEADER PANEL -->
    <?php echo $__env->make('contractor.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: HEADER PANEL -->

    <!-- BEGIN: SIDEBAR PANEL -->
    <?php echo $__env->make('contractor.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: SIDEBAR PANEL -->

    <main class="overflow-auto" id="home-panel">
        <div class="px-md-4 py-4">
        <?php echo $__env->make('contractor.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </main>

    <?php echo $__env->make('contractor.includes.commonJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        var xValues = ["Italy", "France"];
        var yValues = [55, 49];
        var barColors = [
            "#1b4f72",
            "#7fffd4",
        ];

        new Chart("package-detail", {
            type: "doughnut",
            data: {
                labels: xValues,
                datasets: [{
                    backgroundColor: barColors,
                    data: yValues
                }]
            },
            // options: {
            //     title: {
            //         display: true,
            //         text: "World Wide Wine Production 2018"
            //     }
            // }
        });
    </script>

    <script>
        var xValues = ["Italy", "France"];
        var yValues = [55, 49];
        var barColors = [
            "#1b4f72",
            "#7fffd4",
        ];

        new Chart("lead-refund", {
            type: "doughnut",
            data: {
                labels: xValues,
                datasets: [{
                    backgroundColor: barColors,
                    data: yValues
                }]
            },
            // options: {
            //     title: {
            //         display: true,
            //         text: "World Wide Wine Production 2018"
            //     }
            // }
        });
    </script>

    <script>
        var xValues = ["Italy", "France", "USA"];
        var yValues = [16, 35, 49];
        var barColors = [
            "#b0c4de",
            "#4682b4",
            "#7fffd4",
        ];

        new Chart("cunsumtion-details", {
            type: "doughnut",
            data: {
                labels: xValues,
                datasets: [{
                    backgroundColor: barColors,
                    data: yValues
                }]
            },
            // options: {
            //     title: {
            //         display: true,
            //         text: "World Wide Wine Production 2018"
            //     }
            // }
        });
    </script>
</body>

</html><?php /**PATH D:\projects\project\resources\views/contractor/index.blade.php ENDPATH**/ ?>