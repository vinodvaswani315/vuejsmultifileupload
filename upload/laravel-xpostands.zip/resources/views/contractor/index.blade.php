
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @include('contractor.includes.commoncss')
    <link rel="stylesheet" href="{{asset('contractor/assets/css/home.min.css')}}">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
    <title>Home</title>
</head>

<body class="overflow-hidden">
    <!-- BEGIN: HEADER PANEL -->
    @include('contractor.includes.header')
    <!-- END: HEADER PANEL -->

    <!-- BEGIN: SIDEBAR PANEL -->
    @include('contractor.includes.sidebar')
    <!-- END: SIDEBAR PANEL -->

    <main class="overflow-auto" id="home-panel">
        <div class="px-md-4 py-4">
        @include('contractor.home')
        </div>
    </main>

    @include('contractor.includes.commonJS')

    <script>
        var xValues = ["Italy", "France"];
        var yValues = [55, 49];
        var barColors = [
            "#1b4f72",
            "#7fffd4",
        ];

        new Chart("package-detail", {
            type: "doughnut",
            data: {
                labels: xValues,
                datasets: [{
                    backgroundColor: barColors,
                    data: yValues
                }]
            },
            // options: {
            //     title: {
            //         display: true,
            //         text: "World Wide Wine Production 2018"
            //     }
            // }
        });
    </script>

    <script>
        var xValues = ["Italy", "France"];
        var yValues = [55, 49];
        var barColors = [
            "#1b4f72",
            "#7fffd4",
        ];

        new Chart("lead-refund", {
            type: "doughnut",
            data: {
                labels: xValues,
                datasets: [{
                    backgroundColor: barColors,
                    data: yValues
                }]
            },
            // options: {
            //     title: {
            //         display: true,
            //         text: "World Wide Wine Production 2018"
            //     }
            // }
        });
    </script>

    <script>
        var xValues = ["Italy", "France", "USA"];
        var yValues = [16, 35, 49];
        var barColors = [
            "#b0c4de",
            "#4682b4",
            "#7fffd4",
        ];

        new Chart("cunsumtion-details", {
            type: "doughnut",
            data: {
                labels: xValues,
                datasets: [{
                    backgroundColor: barColors,
                    data: yValues
                }]
            },
            // options: {
            //     title: {
            //         display: true,
            //         text: "World Wide Wine Production 2018"
            //     }
            // }
        });
    </script>
</body>

</html>