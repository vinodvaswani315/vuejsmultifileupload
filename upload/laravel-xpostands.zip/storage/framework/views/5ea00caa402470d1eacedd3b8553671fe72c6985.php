<div id="sidebar-menu-list">
    <div class="mb-4">
        <div class="text-info mb-3 ms-5 ps-2">Focused</div>

        <ul class="nav flex-column">
            <li class="nav-item mb-2">
                <a class="nav-link text-white rounded-3 px-3 item-link d-flex align-items-center active" aria-current="page" href="index.php">
                    <i class="bi bi-speedometer2"></i>
                    <div class="ms-4">Dashboard</div>
                </a>
            </li>
            <li class="nav-item mb-2">
                <a class="nav-link text-white rounded-3 px-3 item-link d-flex align-items-center" href="#">
                    <i class="bi bi-file-earmark-text"></i>
                    <div class="ms-4">Invoices</div>
                </a>
            </li>
            <li class="nav-item mb-2">
                <a class="nav-link text-white rounded-3 px-3 item-link d-flex align-items-center" href="#">
                    <i class="bi bi-wallet2"></i>
                    <div class="ms-4">Buy Lead Credits</div>
                </a>
            </li>
        </ul>
    </div>

    <div class="mb-4">
        <div class="text-info mb-3 ms-5 ps-2">Listings & Branding</div>

        <ul class="nav flex-column">
            <li class="nav-item mb-2">
                <a class="nav-link text-white rounded-3 px-3 item-link d-flex align-items-center" href="realized-stand.php">
                    <i class="bi bi-file-earmark-bar-graph"></i>
                    <div class="ms-4">Realized Projects</div>
                </a>
            </li>
            <li class="nav-item mb-2">
                <a class="nav-link text-white rounded-3 px-3 item-link d-flex align-items-center" href="#">
                    <i class="bi bi-file-earmark-plus"></i>
                    <div class="ms-4">Add Projects</div>
                </a>
            </li>
            <li class="nav-item mb-2">
                <a class="nav-link text-white rounded-3 px-3 item-link d-flex align-items-center" data-bs-toggle="collapse" href="#collapseMyBrand" role="button" aria-expanded="false" aria-controls="collapseMyBrand">
                    <i class="bi bi-award"></i>
                    <div class="ms-4">My Brand</div>
                </a>

                <div class="collapse" id="collapseMyBrand">
                    <div class="card bg-transparent border-0 card-body py-0">
                        <ul class="nav flex-column ms-4">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="my-brand-office.php">Office</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="my-brand-presentation.php">Presentation</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="scope.php">Scope</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </li>
            <li class="nav-item mb-2">
                <a class="nav-link text-white rounded-3 px-3 item-link d-flex align-items-center" href="reviews.php">
                    <i class="bi bi-star"></i>
                    <div class="ms-4">Reviews</div>
                </a>
            </li>
        </ul>
    </div>

    <div class="mb-0">
        <div class="text-info mb-3 ms-5 ps-2">Account Management</div>

        <ul class="nav flex-column">
            <li class="nav-item mb-2">
                <a class="nav-link text-white rounded-3 px-3 item-link d-flex align-items-center" href="my-profile.php">
                    <i class="bi bi-star"></i>
                    <div class="ms-4">My Profile</div>
                </a>
            </li>
            <li class="nav-item mb-2">
                <a class="nav-link text-white rounded-3 px-3 item-link d-flex align-items-center" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                    <i class="bi bi-box-arrow-right"></i>
                    <div class="ms-4">Logout</div>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                    </form>
                </a>
            </li>
        </ul>
    </div>
</div><?php /**PATH E:\xpostand\resources\views/contractor/includes/sidebar-menu-list.blade.php ENDPATH**/ ?>