<?php
use App\Models\UserRole;
function GetUserRole($user_id)
{
    
    $check = UserRole::join('users','users.id','=','user_roles.user_id')
                    ->join('roles','roles.id','=','user_roles.role_id')
                    ->where('user_id','=',$user_id)->first();
    return $check->label;
    
} 