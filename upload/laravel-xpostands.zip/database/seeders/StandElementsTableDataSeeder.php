<?php

namespace Database\Seeders;

use App\Models\StandElements;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class StandElementsTableDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $elements = array(
            array(
                'item_name' => "Counter",
                'icon' => "counter.svg"
            ),
            array(
                'item_name' => "Furniture",
                'icon' => "furniture.svg"
            ),
            array(
                'item_name' => "Multimedia",
                'icon' => "multimedia.svg"
            ),
            array(
                'item_name' => "Closed Meeting Room",
                'icon' => "closed-meeting.svg"
            ),
            array(
                'item_name' => "Open Meeting Room",
                'icon' => "open-meeting.svg"
            ),
            array(
                'item_name' => "Space Storage",
                'icon' => "space-storage.svg"
            ),
            array(
                'item_name' => "Catering Area",
                'icon' => "catering.svg"
            ),
            array(
                'item_name' => "Hanging elements",
                'icon' => "hanging.svg"
            ),
        );

        foreach($elements as $element)
        {
            StandElements::create([
                'item_name' => $element['item_name'],
                'icon' => $element['icon']
            ]);
        }
    }
}
