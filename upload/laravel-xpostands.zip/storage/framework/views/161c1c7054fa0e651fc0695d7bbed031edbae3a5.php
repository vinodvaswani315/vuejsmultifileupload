<section id="footer-panel" class="mt-auto">
    <div class="bg-dark py-4 py-md-5">
        <div class="container-fluid container-lg">
            <div class="row g-3">
                <div class="col-md-4">
                    <div class="me-md-5">
                        <div class="text-uppercase fw-bold fs-5 text-white mb-4">ABOUT <span class="text-primary">XPO</span>STANDS B.V.</div>
                        <div class="text-primary">XPOSTANDS B.V. has years of experience under its belt, is one of the best exhibition-supporter portals in the Exhibition World.</div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <ul class="nav flex-column mb-0">
                        <li class="nav-item">
                            <a class="nav-link text-white py-1 px-0 active" aria-current="page" href="#">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white py-1 px-0" href="about.php">About XPOStands B.V.</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white py-1 px-0" href="how-it-works.php">How does it Work?</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white py-1 px-0" href="#">Sitemap</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white py-1 px-0" href="#">Contractor Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white py-1 px-0" href="contractor-signup">Contractor Signup</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white py-1 px-0" href="privacy-policy.php">Privacy Policy</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white py-1 px-0" href="terms-and-conditions.php">Terms & Conditions</a>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="fw-fw-bolder text-white fs-5 mb-2">SUBSCRIBE TO NEWSLETTER</div>
                    <form action="">
                        <div class="input-group mb-0">
                            <input type="text" class="form-control text-white rounded-0 bg-transparent" placeholder="Your email here..." aria-label="Recipient's username" aria-describedby="button-addon2">
                            <button class="btn btn-primary rounded-0 text-uppercase" type="button" id="button-addon2">Subscribe</button>
                        </div>
                    </form>

                    <ul class="list-inline mt-4 mb-3">
                        <li class="list-inline-item">
                            <a href="" class="social-links text-decoration-none rounded-circle d-flex justify-content-center align-items-center">
                                <i class="fa-brands fa-facebook-f"></i>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="" class="social-links text-decoration-none rounded-circle d-flex justify-content-center align-items-center">
                                <i class="fa-brands fa-twitter"></i>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="" class="social-links text-decoration-none rounded-circle d-flex justify-content-center align-items-center">
                                <i class="fa-brands fa-linkedin-in"></i>
                            </a>
                        </li>
                    </ul>
                    <div><span class="text-primary me-1">E-Mail:</span><a href="mailto:info@xpostands.com" class="text-decoration-none mail-link text-white">info@xpostands.com</a></div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-black py-2">
        <div class="container-fluid container-lg">
            <div class="row">
                <div class="col-12 text-center">
                    <span class="text-white fw-light">Copyrights © 2022 XPOSTANDS B.V. <span class="text-info">All Rights Reserved.</span></span>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH E:\xpostand\resources\views/frontend/includes/footer.blade.php ENDPATH**/ ?>