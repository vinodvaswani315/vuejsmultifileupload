<?php

namespace App\Http\Controllers;

use App\Models\Faq;
use Illuminate\Http\Request;

class FaqController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $faqs['faqs'] = Faq::paginate(20);
        return view('admin.faqs',$faqs);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'question'=>'required',
            'answer'=>'required'
        ]);

        $faq = new Faq();

        $faq -> question = $request -> question;
        $faq -> answer = $request -> answer;
        $faq ->save();

        $request->session()->flash('success','New FAQ Added successfully');
        return redirect('superadmin/faqs/');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Faq  $faq
     * @return \Illuminate\Http\Response
     */
    public function show(Faq $faq)
    {
        return view('admin.faq_add');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Faq  $faq
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
        $data['data'] = Faq::find($id);
        return view('admin.faq_edit',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Faq  $faq
     * @return \Illuminate\Http\Response
     */
    // public function update(Request $request, Faq $faq)
    // {
    //     //
    // }
    public function update(Request $request, $id)
    {

        $request->validate([
            'question'=>'required',
            'answer'=>'required'
        ]);

        $faq = Faq::find($request -> id);

        $faq -> question = $request -> question;
        $faq -> answer = $request -> answer;
        $faq ->update();

        $request->session()->flash('success','Faq has been Updated');
        return redirect('superadmin/faqs/');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Faq  $faq
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        $model = Faq::find($id);        
        if($model->delete()){
            $request->session()->flash("success","Faq has been Deleted");
            return redirect('superadmin/faqs');
            
        }else{
            $request->session()->flash("error","Failed");
            return back();
        }
    }
}
