@extends('layouts.master')
@section('university',"nav-active nav-expanded")
@section('title','University')

@section('contents')
<section role="main" class="content-body">
    <header class="page-header d-flex">
        <div>
            <a class="page-title-icon" href="{{url('super-admin/dashboard')}}"><i class="fas fa-home"></i></a>
            <h2>University</h2>
        </div>
       
    </header>
    <section class="panel">
        <div class="tabs-custom">
            <ul class="nav nav-tabs">
                <li class="list_data_tab active">
                <a href="#list" data-toggle="tab"><i class="fas fa-list-ul"></i> University List</a>
                </li>
                <li class="create_data_tab">
                <a href="{{ url('super-admin/universities/create') }}"><i class="far fa-edit"></i> Create University</a>
                </li>
                <li class="edit_data_tab" >
                <a href="#edit-form" data-toggle="tab" id="edit-form-achor"><i class="far fa-edit"></i> Edit Record</a>
                </li>
            </ul>
            <div class="tab-content">

                <div id="list" class="tab-pane active"> 
                    <div class="mb-md">
                        <table class="table table-bordered table-hover table-condensed mb-none table-export">
                            <thead>
                                <tr>
                                <th width="50">Sl</th>
                                <th>University Name</th>
                                <th>College Name</th>
                                <th>Email</th>
                                <th>Mobile No</th>
                                <th>City</th>
                                <th>State</th>
                                <th>Link</th>
                                <th>Address</th>
                                <th>Logo</th>
                                <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($university as $item)
                                <tr>
                                    <td>{{$item->id}}</td>
                                    <td>{{$item->university_name}}</td>
                                    <td>{{$item->college_name}}</td>
                                    <td>{{$item->email}}</td>
                                    <td>{{$item->mobile}}</td>
                                    
                                    <td>{{$item->city}}</td>
                                    <td>{{$item->state}}</td>
                                    <td>{{$item->link}}</td>
                                    <td>{{$item->address}}</td>
                                    <td>
                                        
                                        <img class="" src="{{asset('storage/uploade/')}}/{{$item->logo}}" width="100" height="40">

                                    </td>
                                    <td class="min-w-c d-flex">
                                    <!--update link-->
                                    
                                    <form>
                                    <a  href="{{url('super-admin/universities/'.$item->id.'/edit')}}" class="btn btn-default btn-circle icon" onclick="edit_record({{$item->id}})">
                                    <i class="fas fa-pen-nib"></i>
                                    </a>
                                    </form>
                                    <!-- delete link -->
                                    <form id="delete-form-{{$item->id}}" 
                                        + action="{{route('universities.destroy', $item->id)}}"
                                        method="post">
                                       
                                      @csrf @method('DELETE')
                                      <button class='btn btn-danger icon btn-circle show_confirm' type="submit" data-toggle="tooltip" title='Delete' ><i class='fas fa-trash-alt'></i></button>
                                       
                                    </form>
                                    
                                    </td>
                                </tr>   
                                @endforeach
                               
                            </tbody>
                        </table>
                    </div>
                </div>
              
            </div>
        </div>
    </section>
 </section>
@endsection
@section('js')
<script>
    
    $(document).ready(function(){
        $('.edit_data_tab').hide();

        $('.list_data_tab').click(function(){

            $('.create_data_tab').show();
            
            $('.edit_data_tab').hide();
            
            $('input').val('');

        });
         $(document).on('click','#add_university_submit',function(){
               
               var data = {
                  'university_name': $('#university_name').val(),

                  'college_name': $('#college_name').val(),

                  'email': $('#email').val(),

                  'mobile': $('#mobile').val(),

                  'city': $('#city').val(),
                  
                  'state': $('#state').val(),
                  
                    'link': $('#link').val(),
                                    
                    'logo': $('#logo').val(),

                  'address': $('#address').val(),

               }

               $.ajaxSetup({

                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }

                });

               $.ajax({

                  url: "{{url('super-admin/universities')}}",

                  type: "POST",

                  data: data,

                  datatype: "json",

                  success: function (response){

                  console.log(response); 

                     if(response.status == 400)
                     {
                        if(response.errors.university_name){
                            $('.university_name_error').html(`<span class="text-danger">${response.errors.university_name}</span>`)

                        }
                        if(response.errors.college_name){
                            $('.college_name_error').html(`<span class="text-danger">${response.errors.college_name}</span>`)
                            console.log("test1");

                        }
                        if(response.errors.email){
                            $('.email_error').html(`<span class="text-danger">${response.errors.email}</span>`)
                            console.log("test1");

                        }
                        if(response.errors.mobile){
                            $('.mobile_error').html(`<span class="text-danger">${response.errors.mobile}</span>`)
                            console.log("test1");

                        }
                        
                        if(response.errors.city){
                            $('.city_error').html(`<span class="text-danger">${response.errors.city}</span>`)
                            console.log("test1");

                        }
                        
                        if(response.errors.state){
                            $('.state_error').html(`<span class="text-danger">${response.errors.state}</span>`)
                            console.log("test1");

                        }
                        
                        if(response.errors.address){
                            $('.address_error').html(`<span class="text-danger">${response.errors.address}</span>`)
                            console.log("test1");

                        }
                        
                     }
                     else
                     {
                        $('input').val('');

                        $('.error_div').html('');

                        toastr.options =
                        {
                            "closeButton" : true,
                            "progressBar" : true,
                            "positionClass": "toast-top-right"
                        }
                        toastr.success(response.message);

                        setTimeout(function() {

                            location.reload();
                            
                        }, 1000);
                        
                        
                     }

                  }
               });
         });

    });
</script>


@endsection