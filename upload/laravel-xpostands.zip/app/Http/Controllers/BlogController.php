<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $blogs['blogs'] = Blog::paginate(1);
        return view('admin.blogs',$blogs);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'question'=>'required',
            'answer'=>'required'
        ]);

        $blog = new Blog();

        $blog -> question = $request -> question;
        $blog -> answer = $request -> answer;
        $blog ->save();

        $request->session()->flash('success','New Blog Added successfully');
        return redirect('superadmin/blogs/');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Blog  $blog
     * @return \Illuminate\Http\Response
     */
    public function show(Blog $blog)
    {
        return view('admin.blog_add');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Blog  $blog
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
        $data['data'] = Blog::find($id);
        return view('admin.blog_edit',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Blog  $blog
     * @return \Illuminate\Http\Response
     */
    // public function update(Request $request, Faq $blog)
    // {
    //     //
    // }
    public function update(Request $request, $id)
    {

        $request->validate([
            'question'=>'required',
            'answer'=>'required'
        ]);

        $blog = Blog::find($request -> id);

        $blog -> question = $request -> question;
        $blog -> answer = $request -> answer;
        $blog ->update();

        $request->session()->flash('success','Blog has been Updated');
        return redirect('superadmin/blogs/');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Blog  $blog
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        $model = Blog::find($id);        
        if($model->delete()){
            $request->session()->flash("success","Blog has been Deleted");
            return redirect('superadmin/blogs');
            
        }else{
            $request->session()->flash("error","Failed");
            return back();
        }
    }
}
