<?php

namespace Database\Seeders;

use App\Models\Role;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class RolesTableDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Role::create([
            'role' => "Superadmin",
            'label' => "Superadmin"
        ]);

        Role::create([
            'role' => "Contractor",
            'label' => "Contractor"
        ]);
    }
}
