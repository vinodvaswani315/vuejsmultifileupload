<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>All Enquiries</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <?php echo $__env->make('admin.includes.common-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.4.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- ======= Header Ends ======= -->
  
  <!-- ======= Sidebar ======= -->
  <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Enquiries</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
          <li class="breadcrumb-item active">Enquiries</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body pt-3">

                            <!-- Bordered Tabs -->
                            <ul class="nav nav-tabs nav-tabs-bordered" id="borderedTab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                                        data-bs-target="#bordered-home" type="button" role="tab" aria-controls="home"
                                        aria-selected="true">Details</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="profile-tab" data-bs-toggle="tab"
                                        data-bs-target="#bordered-profile" type="button" role="tab"
                                        aria-controls="profile" aria-selected="false"
                                        tabindex="-1">Conversation</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="contact-tab" data-bs-toggle="tab"
                                        data-bs-target="#bordered-contact" type="button" role="tab"
                                        aria-controls="contact" aria-selected="false" tabindex="-1">Performance</button>
                                </li>
                            </ul>
                            <div class="tab-content pt-3" id="borderedTabContent">
                                <!-- ============================================================== -->
                                <!-- Details Tab -->
                                <!-- ============================================================== -->
                                <div class="tab-pane fade show active" id="bordered-home" role="tabpanel"
                                    aria-labelledby="home-tab">
                                    <div class="row g-4">
                                        <div class="col-md-6">
                                            <table class="table table-striped-columns">
                                                <thead>
                                                    <tr>
                                                        <th calspan="2" scope="col">
                                                            Contact Details
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody class="table-group-divider">
                                                    <tr>
                                                        <th scope="row">Code no.</th>
                                                        <td>#<?php echo e($data->id); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Contact name</th>
                                                        <td><?php echo e($data->contact_person_name); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Contact no.</th>
                                                        <td><?php echo e($data->contact_number); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Contact email</th>
                                                        <td><?php echo e($data->email); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Company name</th>
                                                        <td><?php echo e($data->company); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Company website</th>
                                                        <td><?php echo e($data->website); ?></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="col-md-6">
                                            <table class="table table-striped-columns">
                                                <thead>
                                                    <tr>
                                                        <th calspan="2" scope="col">
                                                            Event Details
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody class="table-group-divider">
                                                    <tr>
                                                        <th scope="row">Event name</th>
                                                        <td><?php echo e($data->event_name); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Event country</th>
                                                        <td><?php echo e($data->event_country); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Event city</th>
                                                        <td><?php echo e($data->event_country); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Event web</th>
                                                        <td>fieuro.com</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Start date</th>
                                                        <td><?php echo e($data->show_start); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">End date</th>
                                                        <td><?php echo e($data->show_end); ?></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="col-md-12">
                                            <table class="table table-striped-columns">
                                                <thead>
                                                    <tr>
                                                        <th calspan="2" scope="col">
                                                            Brief
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody class="table-group-divider">
                                                    <tr>
                                                        <th scope="row">Brief Source</th>
                                                        <td>Direct/submitted by agency</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Stand Area</th>
                                                        <td><?php echo e($data->stand_size); ?> - <?php echo e($data->stand_size_unit); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Booking Status</th>
                                                        <td>Yes, I already booked the space and locator</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Service Type</th>
                                                        <td>Inoed Stand Design Construction and assembly</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Stand Elements</th>
                                                        <td>Counter, Furniture, Multi-media etc.</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Budget</th>
                                                        <td>Between $30000 and $6000</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Exhibition Comments</th>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Xpo Stand Comments</th>
                                                        <td></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="col-md-12">
                                            <table class="table table-striped-columns">
                                                <thead>
                                                    <tr>
                                                        <th calspan="2" scope="col">
                                                            Attachments
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody class="table-group-divider">
                                                    <tr>
                                                        <td class="py-3">
                                                            <div class="row g-3">
                                                                <div
                                                                    class="col-12 d-flex justify-content-end align-items-center">
                                                                    <button type="button"
                                                                        class="btn btn-primary btn-sm"><i
                                                                            class="bi bi-download"></i> Download
                                                                        Bundles</button>
                                                                </div>
                                                                <div class="col-sm-6 col-md-3">
                                                                    <div
                                                                        class="d-flex justify-content-center align-items-center w-100">
                                                                        <label for="dropzone-file"
                                                                            class="upload-box d-flex justify-content-center align-items-center w-100 flex-column border border-2 cursor-pointer rounded-3"
                                                                            style="border-style: dashed!important">
                                                                            <div
                                                                                class="d-flex justify-content-center align-items-center w-100 flex-column py-4">
                                                                                <div
                                                                                    class="text-center text-muted display-6">
                                                                                    <i
                                                                                        class="bi bi-file-earmark-plus"></i>
                                                                                </div>
                                                                                <div class="text-center mt-2">
                                                                                    <b>Add file(s)</b>
                                                                                </div>
                                                                            </div>
                                                                            <input id="dropzone-file" type="file"
                                                                                class="d-none">
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 col-md-3">
                                                                    <div
                                                                        class="card shadow-sm bg-light rounded-3 h-100 d-flex justify-content-center align-items-center border-0 p-3">
                                                                        <b>PDF File</b>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 col-md-3">
                                                                    <div
                                                                        class="card shadow-sm bg-light rounded-3 h-100 d-flex justify-content-center align-items-center border-0 p-3">
                                                                        <b>Image File</b>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="col-md-12">
                                            <table class="table table-striped-columns">
                                                <thead>
                                                    <tr>
                                                        <th calspan="2" scope="col">
                                                            Samples
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody class="table-group-divider">
                                                    <tr>
                                                        <td class="py-3">
                                                            <div class="row g-3">
                                                                <?php
                                                                    for ($i=1; $i <= 3; $i++) { ?>
                                                                <div class="col-sm-6 col-md-3">
                                                                    <div
                                                                        class="card shadow-sm bg-light rounded-3 h-100 d-flex justify-content-center align-items-center border-0 p-3">
                                                                        <b>Sample <?php echo $i; ?></b>
                                                                    </div>
                                                                </div>
                                                                <?php } ?>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="col-md-12">
                                            <table class="table table-sm">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">
                                                            Name
                                                        </th>
                                                        <th scope="col">
                                                            Email
                                                        </th>
                                                        <th scope="col">
                                                            Phone
                                                        </th>
                                                        <th scope="col">
                                                            Status
                                                        </th>
                                                        <th scope="col">
                                                            Accepted
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody class="table-group-divider">
                                                    <?php
                                                        for ($i=1; $i <= 3; $i++) { ?>
                                                    <tr>
                                                        <th scope="row">
                                                            MNA Stands
                                                        </th>
                                                        <td>
                                                            gnavara@gmail.com
                                                        </td>
                                                        <td>
                                                            +32456565656
                                                        </td>
                                                        <td>In-Process</td>
                                                        <td>25-oct-2022</td>
                                                    </tr>
                                                    <?php } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                                <!-- ============================================================== -->
                                <!-- Conversation Tab -->
                                <!-- ============================================================== -->
                                <div class="tab-pane fade" id="bordered-profile" role="tabpanel"
                                    aria-labelledby="profile-tab">
                                    <div class="row g-4">
                                        <div class="col-md-6">
                                            <table class="table table-striped-columns">
                                                <thead>
                                                    <tr>
                                                        <th calspan="2" scope="col">
                                                            Lead Details
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody class="table-group-divider">
                                                    <tr>
                                                        <th scope="row">Lead no.</th>
                                                        <td>#5286</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Lead name</th>
                                                        <td>Vivek Madhok</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Lead no.</th>
                                                        <td>+91 25454545</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Lead email</th>
                                                        <td>vivek@gmail.com</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Company name</th>
                                                        <td>xyz pvt. ltd.</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Company website</th>
                                                        <td>xyz.com</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="col-md-6">
                                            <table class="table table-striped-columns">
                                                <thead>
                                                    <tr>
                                                        <th calspan="2" scope="col">
                                                            Event Details
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody class="table-group-divider">
                                                    <tr>
                                                        <th scope="row">Event name</th>
                                                        <td>Fi Euro 2022</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Event country</th>
                                                        <td>France</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Event city</th>
                                                        <td>Paris</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Event web</th>
                                                        <td>fieuro.com</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Start date</th>
                                                        <td>12 oct, 2022</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">End date</th>
                                                        <td>22 oct, 2022</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="row g-3 mt-4">
                                        <div class="col-md-4 d-flex align-items-center">
                                            <h4 class="mb-0 fw-bold text-primary">Exhibition Conversation</h4>
                                        </div>
                                        <div class="col-md-4 d-flex align-items-center">
                                            <div class="d-flex align-items-center g-3">
                                                <label for="">Status</label>
                                                <select class="form-select ms-3" aria-label="Default select example">
                                                    <option selected>Invoiced</option>
                                                    <option value="1">Recived</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4 d-flex align-items-center">
                                            Next Follow-up: 02 oct, 20220
                                        </div>
                                    </div>

                                    <div class="responsive-table mt-3">
                                        <table class="table table-striped-columns">
                                            <tbody class="table-group-divider">
                                                <tr>
                                                    <th scope="row">12 oct 2022</th>
                                                    <td>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste
                                                        vero ducimus facere doloribus deleniti modi adipisci natus
                                                        harum, tempora et.</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">13 oct 2022</th>
                                                    <td>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste
                                                        vero ducimus facere doloribus deleniti modi adipisci natus
                                                        harum, tempora et.</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <h4 class="mb-0 fw-bold mt-4 text-primary">Contractor</h4>
                                    <div class="responsive-table mt-3">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th scope="col">
                                                        Name
                                                    </th>
                                                    <th scope="col">
                                                        Email
                                                    </th>
                                                    <th scope="col">
                                                        Phone
                                                    </th>
                                                    <th scope="col">
                                                        Status
                                                    </th>
                                                    <th scope="col">
                                                        Next Follow-up
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody class="table-group-divider">
                                                <tr>
                                                    <th scope="row">
                                                        MNA Stands
                                                    </th>
                                                    <td>
                                                        gnavara@gmail.com
                                                    </td>
                                                    <td>
                                                        +32456565656
                                                    </td>
                                                    <td>In-Process</td>
                                                    <td>25-oct-2022</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="responsive-table mt-3">
                                        <table class="table table-striped-columns">
                                            <tbody>
                                                <tr>
                                                    <th scope="row">12 oct 2022</th>
                                                    <td>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste
                                                        vero ducimus facere doloribus deleniti modi adipisci natus
                                                        harum, tempora et.</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">13 oct 2022</th>
                                                    <td>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste
                                                        vero ducimus facere doloribus deleniti modi adipisci natus
                                                        harum, tempora et.</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <!-- ============================================================== -->
                                <!-- Performance Tab -->
                                <!-- ============================================================== -->
                                <div class="tab-pane fade" id="bordered-contact" role="tabpanel"
                                    aria-labelledby="contact-tab">
                                    <h1 class="lead fw-bold">Performance Detail: <span class="fw-normal">Short listed
                                            per actions</span></h1>

                                    <div class="d-flex gap-2 align-items-center w-100">
                                        <button type="button"
                                            class="btn btn-sm btn-primary gap-1 py-1 d-flex align-items-center">
                                            Total Sent <span class="badge bg-white text-primary">20</span>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-primary gap-1 py-1 d-flex align-items-center">
                                            Total Opened <span class="badge bg-white text-primary">20</span>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-primary gap-1 py-1 d-flex align-items-center">
                                            Accepated <span class="badge bg-white text-primary">20</span>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-primary gap-1 py-1 d-flex align-items-center">
                                            Refused <span class="badge bg-white text-primary">20</span>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-primary gap-1 py-1 d-flex align-items-center">
                                            Mixed <span class="badge bg-white text-primary">20</span>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-primary gap-1 py-1 d-flex align-items-center">
                                            Exbited <span class="badge bg-white text-primary">20</span>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-primary gap-1 py-1 d-flex align-items-center">
                                            Exhausted <span class="badge bg-white text-primary">20</span>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-primary gap-1 py-1 d-flex align-items-center">
                                            Package <span class="badge bg-white text-primary">20</span>
                                        </button>
                                    </div>

                                    <div class="mt-4 table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th scope="col">
                                                        S.No.
                                                    </th>
                                                    <th scope="col">
                                                        Comapny
                                                    </th>
                                                    <th scope="col">
                                                        Email
                                                    </th>
                                                    <th scope="col">
                                                        Created
                                                    </th>
                                                    <th scope="col">
                                                        Modified
                                                    </th>
                                                    <th scope="col">
                                                        Status
                                                    </th>
                                                    <th scope="col">
                                                        Sate changed
                                                    </th>
                                                    <th scope="col">
                                                        Actions
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody class="table-group-divider">
                                                <tr>
                                                    <td>1</td>
                                                    <td>Wipro LTD</td>
                                                    <td>wipro@gmail.com</td>
                                                    <td>22 oct, 2022</td>
                                                    <td>25 oct, 2022</td>
                                                    <td>In Process</td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div><!-- End Bordered Tabs -->

                        </div>
                    </div>
                </div>
            </div>
        </section>

  </main><!-- End #main -->

 <!-- ======= Footer ======= -->
 <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <?php echo $__env->make('admin.includes.common-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH E:\laravel-xpostands\resources\views/admin/enquiries-details.blade.php ENDPATH**/ ?>