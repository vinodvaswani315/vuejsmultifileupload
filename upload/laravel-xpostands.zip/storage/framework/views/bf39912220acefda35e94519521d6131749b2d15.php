<!doctype html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <?php echo $__env->make('frontend.includes.commoncss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/contractor-signup.min.css')); ?>">
    <title>Contractor Signup</title>
</head>

<body class="d-flex flex-column h-100" id="xpoapp">
    <!-- BEGIN: HEADER PANEL -->
    <?php echo $__env->make('frontend.includes.secondryheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: HEADER PANEL -->

    <main class="add-secondary-header">
        <section class="hero-section py-4" style="background-image: url(frontend/images/Group-min1231.png);">
            <div class="container-fluid container-sm my-lg-5">
                <div class="row g-3">
                    <div class="col-md-12 mx-auto">
                        <div class="card border-0 rounded-3 shadow-lg">
                            <div class="card-body p-lg-4">
                                <div class="fs-3 mb-0">Create a Free Account</div>
                                <div class="lead mb-4">Please fill in below form to create an account with us.</div>

                                <form id="signupForm" action="contractor-signup" class="needs-validation" @submit.prevent="onSubmit" method="post">
                                <?php echo e(csrf_field()); ?>

                                    <div class="row g-3 g-xl-4">
                                        <div class="col-lg-6">
                                            <div class="row g-3">
                                                <div class="col-md-12">
                                                    <div class="h4 text-primary fw-bold w-100 border-bottom pb-3">Personal Details</div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input type="text" class="form-control" ref="first_name" v-model="formData.first_name"  placeholder="Your Name">
                                                        <div class="invalid-feedback">
                                                            Please enter first name.
                                                        </div>
                                                        <label for="first_name">First Name</label>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input type="text" class="form-control" ref="last_name" v-model="formData.last_name" placeholder="Your Name">
                                                        <div class="invalid-feedback">
                                                            Please enter last name.
                                                        </div>
                                                        <label for="last_name">Last Name</label>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input type="email" class="form-control" id="email" v-model="formData.email" placeholder="Your Name">
                                                        <div class="invalid-feedback">
                                                            Please enter email.
                                                        </div>
                                                        <label for="email">E-Mail Id</label>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input type="text" class="form-control" id="contact_number" placeholder="Your Name">
                                                        <div class="invalid-feedback">
                                                            Please enter contact number.
                                                        </div>
                                                        <label for="contact_number">Contact Number</label>
                                                    </div>
                                                    
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-floating">
                                                        <input type="text" class="form-control" ref="password" v-model="formData.password" id="password" placeholder="Your Name">
                                                        <div class="invalid-feedback">
                                                            Please enter password.
                                                        </div>
                                                        <label for="password">Password</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row g-3">
                                                <div class="col-md-12">
                                                    <div class="h4 text-primary fw-bold w-100 border-bottom pb-3">Company Details</div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input type="text" class="form-control" id="floatingInput" placeholder="Your Name">
                                                        <label for="floatingInput">Company Name</label>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input type="text" class="form-control" id="floatingInput" placeholder="Your Name">
                                                        <label for="floatingInput">Website URL</label>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <select class="form-select" id="floatingSelect" aria-label="Floating label select example">
                                                            <option selected>Open this select menu</option>
                                                            <option value="1">One</option>
                                                            <option value="2">Two</option>
                                                            <option value="3">Three</option>
                                                        </select>
                                                        <label for="floatingSelect">Select Country</label>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <select class="form-select" id="floatingSelect" aria-label="Floating label select example">
                                                            <option selected>Open this select menu</option>
                                                            <option value="1">One</option>
                                                            <option value="2">Two</option>
                                                            <option value="3">Three</option>
                                                        </select>
                                                        <label for="floatingSelect">Select City</label>
                                                    </div>
                                                    <small>Select a country to load cities list</small>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="form-floating">
                                                        <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea"></textarea>
                                                        <label for="floatingTextarea">Address</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="row g-3">
                                                <div class="col-md-12 d-none">
                                                    <div class="h4 text-primary fw-bold w-100 border-bottom pb-3">Select Areas of Intervention</div>
                                                </div>
                                                <div class="col-md-6 d-none">
                                                    <div class="form-floating">
                                                        <select class="form-select" id="floatingSelect" aria-label="Floating label select example">
                                                            <option selected>Open this select menu</option>
                                                            <option value="1">One</option>
                                                            <option value="2">Two</option>
                                                            <option value="3">Three</option>
                                                        </select>
                                                        <label for="floatingSelect">Works with selects</label>
                                                    </div>
                                                </div>

                                                <div class="col-md-6 d-none">
                                                    <button class="btn btn-primary text-white btn-lg w-100 h-100">Load Service Cities</button>
                                                </div>

                                                <div class="col-12 bg-light mt-4 py-2">
                                                    <div class="row g-3">
                                                        <div class="col-6">
                                                            <button class="btn btn-dark text-white btn-lg">Back to Login</button>
                                                        </div>
                                                        <div class="col-6 text-end">
                                                            <button class="btn btn-primary text-white btn-lg">Sign Up</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="bg-white py-5">
            <div class="container-fluid container-sm">
                <div class="row g-3">
                    <div class="col-sm-8">
                        <div class="fw-bold text-primary fs-4">Ask for 5 Free Quotations for your Exhibition Stands or Contact Us for more information:</div>
                        <div class="display-4">+31 20 8080653</div>
                    </div>
                    <div class="col-sm-4">
                        <img src="<?php echo e(asset('frontend/images/headphone.png')); ?>" class="img-fluid" alt="">
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- BEGIN: FOOTER PANEL -->
    <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: FOOTER PANEL -->
    
    <?php echo $__env->make('frontend.includes.commonJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</body>

</html><?php /**PATH D:\projects\project\resources\views/frontend/contractor-signup.blade.php ENDPATH**/ ?>